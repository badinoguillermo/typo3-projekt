-- MariaDB dump 10.20-11.8.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.9-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1792413045,1792413045,0,0,0,0,1,'{\"83df3168106284e066908d7952d1d900f4b3522f\":{\"identifier\":\"t3information\"},\"6ab08832a53470e2a6e63c235b5f24aeabdf9a6e\":{\"identifier\":\"docGettingStarted\"}}','61cc00c71aa9ff357533a392922b53d0649e31f1','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1792518004,1792515127,0,0,'','pages,tt_content','Testgruppe','3','','readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',0,'1','pages,tt_content','pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:cache_timeout,pages:cache_tags,pages:canonical_link,pages:categories,pages:sitemap_changefreq,pages:module,pages:rowDescription,pages:description,pages:author_email,pages:hidden,pages:media,pages:no_follow,pages:layout,pages:php_tree_stop,pages:no_search,pages:extendToSubpages,pages:no_index,pages:is_siteroot,pages:keywords,pages:lastUpdated,pages:l18n_cfg,pages:mount_pid_ol,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:sitemap_priority,pages:shortcut_mode,pages:content_from_pid,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:doktype,pages:twitter_card,pages:twitter_description,pages:twitter_image,pages:twitter_title,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:uploads_description,tt_content:uploads_type,tt_content:hidden,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:imagewidth','tt_content:CType:header,tt_content:CType:text,tt_content:CType:list,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:shortcut,tt_content:CType:div,tt_content:CType:html,tt_content:CType:form_formframework,tt_content:CType:felogin_login','',NULL,'web_layout,web_list','','','','0','');
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('330bd7e913ef1f5a07cf5a938b5370c082eaecb3bd5f511cdc6f9b27d033e5a9','[DISABLED]',1,1792686878,'a:3:{s:26:\"formProtectionSessionToken\";s:64:\"4d4f25798788d3d462e78b25a88250947658f0c5c7150da1130cc784c96b04ac\";s:23:\"backend.sudo-mode.claim\";s:2:\"[]\";s:23:\"backend.sudo-mode.grant\";s:305:\"{\"route:\\/module\\/tools\\/extensionmanager\":{\"subject\":{\"class\":\"TYPO3\\\\CMS\\\\Backend\\\\Security\\\\SudoMode\\\\Access\\\\RouteAccessSubject\",\"identity\":\"route:\\/module\\/tools\\/extensionmanager\",\"subject\":\"\\/module\\/tools\\/extensionmanager\",\"lifetime\":\"medium\",\"group\":\"systemMaintainer\"},\"expiration\":1792678328}}\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1792412976,1792412976,0,0,0,0,NULL,'default','a:10:{s:10:\"moduleData\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"61cc00c71aa9ff357533a392922b53d0649e31f1\";s:8:\"web_info\";a:1:{s:6:\"action\";s:17:\"web_info_overview\";}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:6:\"web_ts\";a:1:{s:6:\"action\";s:30:\"web_typoscript_recordsoverview\";}s:23:\"backend_user_management\";a:1:{s:13:\"defaultAction\";s:6:\"groups\";}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:4:{s:32:\"ea5808446ef89a93a3ae0c95ac46d0d0\";a:5:{i:0;s:7:\"Leipzig\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:9;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B9%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:9;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=dd149378390fe0fc53e0811e14f4f8bf920df1e4&id=2#element-tt_content-9\";}s:32:\"4869cf322808343c3d6ca616a691b6a3\";a:5:{i:0;s:47:\"Braille device could remove barriers to science\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:1;s:3:\"pid\";i:9;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=8069f553bf334665a28293afa62f54867abebb86&id=9&table=&pointer=1\";}s:32:\"45c776bcfdb3b1f389c0eee97ec316b5\";a:5:{i:0;s:32:\"Perot Museum announces expansion\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:3;s:3:\"pid\";i:9;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=8069f553bf334665a28293afa62f54867abebb86&id=9&table=&pointer=1\";}s:32:\"2852d3f5b619bb7a4bb2eff52fab7de9\";a:5:{i:0;s:11:\"News Detail\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:10;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=dd149378390fe0fc53e0811e14f4f8bf920df1e4&id=9&\";}}i:1;s:32:\"c793a3d3c03c055bfa922fe796751027\";}s:16:\"browse_links.php\";N;s:16:\"opendocs::recent\";a:8:{s:32:\"c793a3d3c03c055bfa922fe796751027\";a:5:{i:0;s:13:\"News-Speicher\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:9;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B9%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:9;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:89:\"/typo3/module/web/NewsAdministration/?token=3c0323e2bbbddccbeed2c1976b153e5a30e8b9f4&id=9\";}s:32:\"ffbd6ae78a9aa555f88d6295c30fb80c\";a:5:{i:0;s:4:\"News\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:10;s:3:\"pid\";i:10;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=dd149378390fe0fc53e0811e14f4f8bf920df1e4&id=10\";}s:32:\"bb7b9c56464aa52dcf3d889a21e87df5\";a:5:{i:0;s:11:\"News Detail\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:77:\"&edit%5Bpages%5D%5B10%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:10;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=dd149378390fe0fc53e0811e14f4f8bf920df1e4&id=10\";}s:32:\"0d1c7dfc75595e7311ece17f44305463\";a:5:{i:0;s:43:\"Primate thought lost  turns up in Indonesia\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:2;s:3:\"pid\";i:9;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=8069f553bf334665a28293afa62f54867abebb86&id=9&table=&pointer=1\";}s:32:\"ea5808446ef89a93a3ae0c95ac46d0d0\";a:5:{i:0;s:7:\"Leipzig\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:9;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B9%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:9;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=dd149378390fe0fc53e0811e14f4f8bf920df1e4&id=2\";}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:37:\"Drittes Element ist ein Bild mit Text\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=2462e67ce9c48ea8d68c5e2e6f2189e27c6abf23&id=2#element-tt_content-3\";}s:32:\"354d6c8a6cdac8e7617eef8393065f00\";a:5:{i:0;s:15:\"Meine Testseite\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B2%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=2462e67ce9c48ea8d68c5e2e6f2189e27c6abf23&id=2&\";}s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";a:5:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=2462e67ce9c48ea8d68c5e2e6f2189e27c6abf23&id=4&\";}}s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"2\";s:8:\"language\";s:2:\"-1\";s:10:\"showHidden\";s:1:\"1\";}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"831690db7a8ee92cb9b37fd13737514303fbe43e\";s:8:\"web_info\";s:40:\"831690db7a8ee92cb9b37fd13737514303fbe43e\";s:12:\"pagetsconfig\";s:40:\"831690db7a8ee92cb9b37fd13737514303fbe43e\";s:6:\"web_ts\";s:40:\"831690db7a8ee92cb9b37fd13737514303fbe43e\";s:23:\"backend_user_management\";s:40:\"4460e83a47ee0fb19c389e273d2d4784b6db25e7\";s:10:\"system_log\";s:40:\"83eba5b7f82d070e12c69ffea8a0d964733ef76d\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"83eba5b7f82d070e12c69ffea8a0d964733ef76d\";s:10:\"FormEngine\";s:40:\"83eba5b7f82d070e12c69ffea8a0d964733ef76d\";s:16:\"browse_links.php\";s:40:\"58e5328fae143e4c67061a8133fa46e0f0764046\";s:16:\"opendocs::recent\";s:40:\"83eba5b7f82d070e12c69ffea8a0d964733ef76d\";s:10:\"web_layout\";s:40:\"553900726e27f37d0ef9e39ff3d6feb24efe4d78\";s:9:\"clipboard\";s:40:\"f8a0a77002aaa392496667c94ce17c8c283e9345\";}s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:0;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}s:10:\"modulemenu\";s:2:\"{}\";s:10:\"inlineView\";s:267:\"{\"tt_content\":{\"NEW6ad61831cec70027326599\":{\"sys_file_reference\":[1]},\"4\":{\"sys_file_reference\":[2]},\"NEW6ad76bee417f0163218414\":{\"sys_file_reference\":[3]},\"NEW6ada0a7a4189f852441490\":{\"sys_file_reference\":[7]},\"NEW6ada0ceb1784c823576631\":{\"sys_file_reference\":[8]}}}\";s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"300\";}s:17:\"systeminformation\";s:40:\"{\"system_log\":{\"lastAccess\":1792677397}}\";}',0,NULL,'','t3admin','$argon2i$v=19$m=65536,t=16,p=1$OWt2aklnN3RTamhabVVpMQ$F1hfWn/tBXzIg7T7AT2k2xO9HMMuC1Miw9o6IABaMrQ','',0,NULL,'','badinoguillermo@gmail.com','',1,3,NULL,1,NULL,'',NULL,1792671681,NULL),
(2,0,1792516365,1792515895,0,0,0,0,'','default','a:5:{s:10:\"moduleData\";a:3:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";a:5:{i:0;s:23:\"Sanda Island Lighthouse\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=174b012b5b968f1521e29f5c06d201fde6fd0f9b&id=3#element-tt_content-4\";}}i:1;s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";}s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:2:\"-1\";s:10:\"showHidden\";b:1;}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:3:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"a55eaea1997c55e40047bd7b8a71634609667076\";s:10:\"FormEngine\";s:40:\"a55eaea1997c55e40047bd7b8a71634609667076\";s:10:\"web_layout\";s:40:\"b56b604f16ca4f7e047b15efe8862a75272fadf0\";}}',0,NULL,'','willi','$argon2i$v=19$m=65536,t=16,p=1$QU5GSWhlLjdvdk9YZDFCUw$rHCMr/OH0IuWfzmaTv6UGK67Y6k2EKvqIrv9Th67W6g','1',0,'','','','Willi',0,3,'readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile',1,'','','',1792518043,'0'),
(3,0,1792519044,1792519044,0,0,0,0,NULL,'default','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$S0twR1piQnlqQ0lLdlkxRA$Ugb08iTSmSaMsn62GqYsRmGCss0DKV9lEoNzPlmYaoQ','',0,NULL,'','','',1,3,NULL,1,NULL,'',NULL,0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(4,'3_994e9ae97f27e262',1792771000,'x���n9�y���i���-y�q�5&�1V�Xl�.I���=$eG��7�˦H���%9�pDV�uW��Y\ZG�w�RZ�%�DF/Dڹp.K������QJ�/^�����\rY�\"�l���Y��P(�Ϸ�e�-���F��)\rfB�f�Dk�\"H�oӕ���Z ���(��|C�ǧ	�(u%�(��Y�@�$\Z������=F\n��\nJ��Zq W^r򁕨Ua�o+�A�;$*�`y�!\\3��LW���cj%�Vf$J��u�!����ớ��k.��˕!�h4�(��xL�M�|Cq��%J��q\r�E�n�=*�P����\\HU0���<�J��`�	��i�M%;m��a+о��&��7s(�$��o[�%�aB��R�HEI��	�j]}�nD\"�(�P�|B���W\0����ńz��*d\Z��C�u8���.��b��A�͓$��ނ��x��`�t�N\'�() lB��e�-g�,g����A��W�3�,���\r��\0QB`@\rv�\0Ab�2�a9��l�?/2ɑ\n���\rߟ�1	k�7�d��6��r���NY�܊��׆����Ǽ7LX����K�]�@2��b�p4L�ax�7�4��3��l��zÎ��d��+�����:\'<GvZ0Q�&k���RoO0�5���V�GV���=��$@�;��.!�p{�!�@��l�x�������\"\Z�P�&���t��.���RS�rv�<#�I��8[�qC���3N�qD�x��9Gڑ���mΞ:\'�8�ų�0O�챿�(6��B�����w�s�?1w@�]���uu�/��{�,�V\Z{�ID�sp\'��iB?`�Qr�e|�%4�Gh6�n|�(A�j�XV���km\0�7sM^�˲=+���-_� @�X�\\��Լ��~��L��a���mh-��I��A�F*~g�(��7S	^�r��kD\'2�9�a�9αc@�\0�h�p��+�!�i%�;V��fF�un����U_ɵ�C\n.4Ωw��~gM�)��0�N���{���7\"���ғU��%�ܠ6�ڰ\0\\��Dd���{0:A�8��ԕ|xN�� ��;A�XU�\Z/�rm;6O��r�F>%�X˃�s�L��8ޅ�я�(�64���f!{�Q3m�k6t���(n�`IɃ��jB;�P�>��M.Y&l��?�-����\rx\"��6�Ыzy>�v6\rѨϬڏ�����F6��NG�;|�V��<\n�\'�r$�˱�|�dA�%�De[ї����|�s���P\\���w�x�L��a$�ﱾ7��$��r�箙�em�%������2Y��L>a����	e\0G��}��A]�̕{�n���k2N2���5؍�Z�^��L�������3�i���^�������l(G�z%��N�S�/�M�N,k$lc��t+k�\r�r$[��͢x.k����+\"��	��ɯ�6�ր�R���v��-���og�Wk#7�Y�G��HK��Nm�;��(����_$vΞ�g�.0r��K�ИHT;\"(��,/�Q,gD�Lt?+6��\0�_7��4.��5o�4\r�������7�C{`�/��I�=�Z�z�\n�p妺C���ǻ/S�!,(�Ԧ�;t�����e�$)��8%��JT�^�4J��@L�3��`����S;�\\1���퇏�0�s��{�\\I_n�\'��\\�l����^��K��z$���cCƊ�~>qSذۏ\"+s\'�v~|�����ڱ�����\r�ej��/��\r�W���J;ˤ�?�u�Fh5���-�%5H��4��c̬6��$��}�ѳ�B�&�����!�V�R�R�7zf��Y�B{:j@�V����>����uf)�pd�[%�Y�8B��\0�����w`��p��A��Fɼ�p��s<�\r��_pi�}'),
(9,'10_76dee0fa0c23d494',1792772420,'x��Y�n�8����v�f��ϲd��`&���6���\\���������f�i���G�\'�sHɖ�n.�\0��L���񈤉�&��$J��^�Ϭ#cGz(�+�*e��I���5{��Ǔ˟�_��*����HA����*���͎G�f%S��+*$Ss�U��h�¶���r�%�eK�#��ԷL��,���1 6�l���iX����H��^�rM�(�c�nXEd݊���99��U��������+N�⎤�Qe$��ʆ	rqM�XտZe��)�$̷Us����>{8��͝�W+E��4�}ן�:��쐼��H^W��`�e@�V�\",I�Cn+&$�9��Z�T�:��C�ekA52qu���a-���m�G3�U��߱[I^Bx1s���Ĥ_̭+����E�P�-c�����݊�%�]��1e��`��2r+�J��tR)����4N�4\r�<��e����}�u�<�ѷ^4��^��EJ�q:�  Z�h[lJ���)-z�[Fۍ�e��0���!&�S��v���ltL:Ζuv_/�:��lGg�´ݗ���&�C��L���F���5Z���7vÝ3�\'^\Z�>�|�C2�>� ���n�{�sNV�J&씊l��I�q`�j{���X�3��-HZ���UR^�P������)�	=J{]K0�يI%��\"�⹅�`�r=�YKȽ�\rW�B�׿\Z޲V�`2�N����������aK�۷�_��5ۡa���#����3���̐�e�얣��3��c�����G�Sa����0sv��~�p�������X��\r��\Z0�\Z�0���Z74P[~�.H0d����T$��XgPc�Ⱦ�,`�Y�����+\r��i�ͱ��,���FG�F\\���:�9�NR-�\"]����-�i����dm�{;�g�!<��\0����q�$��4�-�1�:mD�Eýn��wu�lwG�}Im�F��KWnM\r��(�n�i ޟ�Y��u>l��v|0�ߛ��E�ώn#��vf`������޲.^}���͂Uf	��_a\\*���[K��n�\Zv ��E��Ot꣖����?�xN6q�y�9�Ѕ��\r��$K�q�uC�C���0ش֏f)6]�LW������pظ����\n��׎���\0�n��^@g\nA��%4^m�AkP���-�P�R��)gU�)mN\r�XwA�6�[�q���7��4������L�����6�n$k�B &�\"|�iOϥo�\\�s�⩗�мM�0�b�J&�7��i�{]2�dC����h��wO�~� \'�A܍�K{t怿�t����=�I�1)�Qi%Ϳ.�7�fL��7�A�\0���������[�Zl\Z�\'�D�=����>k�k��u���|������TDcK�~3\\���A�>��mi+�:o�@�b���!����0@&��/�(	������Ǫ�u|�A2���u]���ӡ^hei�V�����h6��}�\'�m�ݹ�%F|��oQKE�j�\n�\rd\r�)Y\r\r\r�_��Aq��<Z� i�ˈ�0��P.ag~L�C�,n0���>�(>w���rB�ׂ8&jE�Z�ୋVU���.	�n�3���k��\"��2�`b-�i��8��[R�dݏk{�}v`�7|� ^����o3*�]Z=|�^�+^������	Ȟ��&��Gwf����ˤAw\0���}����\ZQ�ڟ3�\'ҧh�ٺc������� y��B�\0��qbaqk���A�9g�%~b����Uz��:�����	f&�3�����\\g]b��P\0|���k\'�����Ň(��=��,�E��}.����i?�N��@蠤�J�wfxO\\�μ ����%U�Baq��Xt^<�{�\"��K�����%y����Dj�$�/�В��:4�^I�\nx񤗤Ԣs��s�.G�=��q��8G�826#\"�H�X�T�������.�\Z/e��xH�%���{ɴ�S �{�;C�S3v���O�\0o.��E��)�i��$O��t�\\/r��.=7��q�����8���!�4'),
(10,'10_c0ae31a5ecc50d94',1792772426,'x��Z�n���m=Ř(��jw���ju),Y��Ďa�(����p9�!f�Zo�\0}�>E����(}�~g��^$�v�I�;�3���0|6̾7��YP񹸑Ip$1v�bUZQڀ~Ng���ߜ_����l���Ӄ弜���}�\nhL��t���BX��k#�IP۴7Ŋ�㧽�yr�I�\"2�\n��J-�	��g|3b=&KSI-�9���r��b��Slwk���T�T%JfT�c��=��\r/!VA�/5/�B�[�V�<_�Xn��_qS	ͮn9י���2a��Ei0_�	�^�����뽵�cU-��g�\r��^8��J������`�HU�[-ֶa�̈́�Ll���� �Rh�c.�T�[�s��=��j?`a[�Y�o��\Z�)=���z��α�6�g��JK�$��:OpP�pHĵ�8�i4����q�o��v+���`.��J���I��?C��a�,oA6?	�]��dB؀eZ�\'��͊��s�~lL�`0���x��I�N��hr0\r�0�4��â?��p4\n+D\"�I\0��#w6��y�J�=uC1�J��ĭ�K��=[��K �$z�}��H%K<�&*�N�\0��?�q�o&�B�YzH��y^:U�U$�{c���7ʼit�?�\'Ӑ\'!Ǔp�C�&Chu0\r���9�l7B�b��N����t�:[��楧�U�,�q�IPpY��Bu��6\\�+�	7�[^-zVkt0\'�I@��_�elknE��a�����ŝ�Y����\Z%�Nxc�q�?)E_D��^�^�79{�����p� �?������I�Ȃ��qD?%x�=Fڑ��A7��z���~.?[\r���t�m�{�a�Aag{�N�ؙ�5�E�=ȴ.��B�}ݯ�o�mt��Dz٭*\n�nX�>�;��k��I����;<�r\rP�#�SGq�X��BvcBR�6�0r^��+Rw�U��B����.�e���6g��{�ǉ�c2A�\"7�J)�2��4�5��_:{ao*9l�r�T��\r���\r�辗}�΍�5s=��a�����?D�B��V�v>���O�^�롕���I�d�F2s�Ѡ��):?Y�����,���Տ��W�ę(��M�7{A���}���~���-�D6t4��+?�T	\n_\\ؐ��>N:�>2Uʮ����s���D?d*^����Kc{��ٍ5V�/VL��:��L$�#H+N�{�A/����t6�a���ԓ��}Z���ޖ�>��v��~A�%�N7���%�kZi�+>�`]ab-+*AW2W��D,�RF�Qd-Y�r�� o���t(�E.y���i3f\\i�+c��u�t�oS��6��qV�\\͗�s\0C�N��h�����ś���8E��ߖ����_��^ְ�Ѵ2�1��#�Nb�78�0��Y�]F��s�-Si!H[,Qˣ,�j�\'`�<�l]c�ت�6T�vZ�Tc���:�Q9��*�ٶ�٬�мZ7\\�g��Z������3T�Oߠ�,-/T$sv���F���k�dtzS{\ri��k�b಼�kC�ݘ־W���??�vӏ�fWzM�n����y�:G�F�խ��=L\'Ҡ�X:�⣷�WvkA�(�����ƍZ�C�h�3d��\Z�0�z�D��-K��\"5H�8�jmjBA��:�h4��E�ܹX�]g�	�r����Vy.��\n��Y3��p�9��t@r���LS�	�{,�t�t]ese��z�E�t�@�#{��V~ҨR�c�kO�*�g7`��-�|�R�\0�,dε3_w4��H�����k��\n�[��?�GH�U=��\"��\nʉ�>]��+�W�<%�Ղ�NǥBlڹ\n�(rgX��DH����#�/��\r�6snnH��@�w��@SC���Bp��zǡ��3,���H���/�$���O�5��`���w1�����i��\r(�ڨ/F����4\0s��&dy�Q�!��N��~�C؏�bgg���ǚ�.i��W�e�b�مb�NN�k���ryGt�6<���:qG6`f4��.�g���b�H�/�\\� �����Q+h?���\rR�X��n���7�cxq��>������2��J#����\\�	�ueo�^A#�2u\\\0:A��\'wigT��\n�]H��?)9i�)��3j�,_�p�\'葴}?��g]�,������!n��fn1��u鱗A:���z11a��H}�%��e	r�Ɣ����s�x	��#���~�6\"S�>Y�d��\"O���^@��H�I���ݙ��Dj������������C4��w�%�	`�;-���1[�A�I&��U���-H����^\0*����}�)�\"��.���i��S�T>w��Tj��_���l���.�5���U\r;�R�H�cW&��i8X�+I��K�T�X�I��dY����w�����>-C)�\'k���y�m>��\rI�5�E���e��/��B\0Mh�{/h��p4b��;��z#{o5N�9(�Jy�-{��M�{���d�/���a\'=��#��F���D�_��O�I���pBf��|iE�p`Y9���<`��҈\'Ī�Ӣ��۲��Ꙁm&��Q��@z���ߺJ�Z�2�\0�bq6��2$ji���H�SӸ����!�Ű�q�E�6qJcj����^���t=z9Ukse�2N�x����gM�jTP�O�&wqa��re-\rG����xTwF�C�lc=�(�׻\Zi��ބ��Q�JI�Q\Z�}m���������絍T�*-���!���3x��u���un�\Z�5Ζ�`��ΖHX�q^Sf�+�h�daD�RM�kR�����gZ����ۅ�Γ6Q��r�,Z�נ�OIjWuB�\Z�TQwC/W�����f�\ZO�YR���k�G��u�⛻�I�\Zq!\\]��j\nc����y������#�0q}IS]7�	���e�:ᡫ��J�;\rC�{���[�Ͽ���v���mh�4��/��ڭ��l��f�i�UM�ԅ�\Z﷋�w���a�5t7��c�}8�>�_/+AC�xPXt���O��K\"m	g���kTW��-8����0��9sCwu�ٱ��M��΁;AsC��?�΂WB��{W�|KW��^	�^��wZ�I���Y��7��\0w�X^T��)����}h�D\Z��n������i�6�S����]�����o�ں�QJ��m��f�_��N:�RI�k>7D�p���\r����i4~38V�����܄4���hd�>2����o�/hdB<��nEws7�Bh�#CZ�\n�.�e�\'01m��M��04t���ܩ�c�*ٴ�<8�P�)�&�q8���~̇��q������$:����(�/�we!'),
(11,'10_4b78aea429971fcf',1792772459,'x��Z�rǕ�->E{j��[�u@��LI��(�d�IǕݤX=3\rL�s�t ��<D^\"��Gɓ�;�{��T~�/�������\\L\'����tTr��t<�h{�MqYXU�\0�����\"����o^����+��<�:����bu�b��M@mJ&WG�\\��J��6�^�]�0����P=�M�m��תܨZ%\"�\n���L�.L�k]�D��*S�`=���̓bY+%�JM+��I.������׵�զ�ﱨ�Zf�Vĵ����{i*U��{)��A�\"��Ua��	�^��n������u\\V�Z�R+���g�p��r�p�����1�, m�z�0ئJעV�[��A6��\r�yS,�:��X�G���5X�Vf1�mU�Fe�\Z\r���х�6SW׵�l(--�,+��65�h*�A�)��PFˋ��r�lV@W��JAi�:�.w�W����(��=d�.c��2�R6i�����˪�\ZK0�ؘ��d:���cϗ˳�<���g�(���|��0�7����x:���@�*��2��xˣ�mcY���e��aU�?�{;J�����1��Դ��ع�ET&[||��1f������S�-ƾ�)����Yi�k\'K�jE\'�o�\Z}�W����4���2	ex<O�e����|\n�N������l�4�ƲN:}����g3�*�؞��驇~5��3lw�RC�Ot�^�v���V�ʚ��jh��FA��_�%n���\\!��VK���E��V�U&BA��v�V�������������0�����%; �lO�\'�9(�G��<�#��=1��>���?gO-��;�̠�\'G=%��8ӟ����!�=����n�����G�gb6�o/�1(�iT�`!t��� ��]h@��p_��4\"x��\Z�~���[��u�WB�Ny���.���d7�4��_�W��b\\����7q�)�T��&��2�~�]t�{�E��B\'��)���֒R��@ҥl���E�9$����Էer[6v89k�$��(�ܙ{]=s=9��������P��p���zG�7|���;�:4�S������Af�\rWF����/k�c4�`n@a\0��W�J��e`�*��K^��X���}��������#������B��\n���P��Zc�r�p�eY��v��|Ɓ��Q�L%�����6vH��l��\Z1��:��S�� ���#��a�NO�����דp1�tK=�N�a8����c��J3&q�����P=8�Q����A�=�x�`��ϣL\\늨�������PmU2kU�yـ�w&\"�*Q�VD\n��!6N\rC�X�^�T��l@��}1�U�Գ���MNuB�\0&%i�c���^��gĖA�_����{Mu���~fdBf%��R&F�̲� W\"���5A9���Y	�Id��b��b�12�T��;c�^de���:��q���\Z&t�Z�׋Teը�U�Zޘ�_��v#:&�2��0�m��e�7�ݗ`y����v�۱�yal�lEՆ<	KK���j��T��*��Z�:7N�4�Z���@�Z����[��@�_��m$��ϛc��8�i�5�H?�K�	M��B��w$n�]�I1��9F/�(,^��q>y,��:�ԬT��n��!*;V9�k�i��g���C�\0���\'�v*s*�h�r�o%��,�N)�%^���`Au-���%)��-�(�\rŭ�!��\\�Z�	!�	\0��]��V���E}�t�[B�,D�F�%��]�%V��j�\rM�%�ߠ^�$J㔤�&�ez�?�#��+\\GF|\0V-��L.�x���\n��5~����薂��W���x�$D�ܦ|�Q���4��]~l�Ա��^ ���s���5v�l����!p5�k\n*:6ℭ��c�@��;���\\�t>����l��V����_��\"�/a8j��@Q;�޹�\0�˗D��,DD��תE�`<��*.�D8������lP���ʠ���OA��\r��N�9��on6r�y���=�pN�����8\0a�s/��wr\r}~�j(x���N�_���Uo�V��:��>b��܊�!�mD������̢ M>	a�@D���N��dN���8j����s�s�y���\0D\0�w�����.��Tڴ�G���Qu\"����Y�}:@�A��l�h�n	����~�L����W8�d�l��򇦓��鰙ۻ$�	|��:s�A3�?��I%��W_��5>�/��B��8Xm���r��8�.[��!�0Vx�ֽ�Ylo��?��G\"x�)(t�<�����U��oG!D3i���f\n:$�/�؎a/�F�@�@T�Q����k%x��ܮE��S�,\'�TX�\Z\\��l�[̕po�MYgN�ME\0*\Z�q#׭�Gƕ��z�У��21��z���!^�]�=-�q0�����C�4��3�X�-\r������Q8j�ӬVt�g�P��H}�7߸�{tfO޽\r��I���EЍ,UC	]��@⭖�UtY��\0�lD����㑞Բ�\r�������N`,��z��%�MW\'��s \n���tE�M��2�|ӹ#4B���G(�����e̠�f;��.�_��=�/D�!큈���) �\"sX\r6ف�����\"\n�|*����A9�]uU���W�$���8�\nEVT����$@�U+�b�3몂��|\'�S[�e�\'�V�ǵ��QT�ge٠�+eK,�*0R�׼#�Udq�I\n�4e��^�^t)�l���\r�>�����.��9��D��Ph[n�`S�(u�0�w�����`2��7����8p�-��:�\Z��a�I�Έ�p���Q����\'jTPf�R�\r�.0�n28\"��{�r��6uQ�N�f����ũ�`$c��Ͽ���mP3�g�d���aJ�!Ev1<�f��!!��	�Jʄ�g��\"q��Z�B䢵Co�A\\�t˵|���4	�iSX�Z��\n��{��Tz�\'�/\n�E�c6��w�0�8q�p��p�U\r�٥!V��Q�\"�c`�c%d]4���l�K.�L����\"�1�j˙G��+�\r=����\nc�ߺ�����I��d�\";+d*��I�x��3�o?��JD��J�2(R�9]\"G���#���g\rT��1N��9�a����ÒL\\���-�aЧ._)tJ�����l=w~\\��4Z����Uɬ%N\"�Ǧ+f-̓?�|��j�b�.lք�O\"-=go�u�1�2�|�զ�M/U񃆏�1`wG�Շ\n���Ŝ������+p&~�#N	���������^�&@�	�JV̗\\�G!�\\�\r�r��,�Mq�����\\�U�.�p�?&��˧܈� J��ܲ����9�Y	c�-������ߵx��)\Z���)p� $�!�c(�Z��sm5��i8e���m�4��n��:(�\"���-܄L��H�� c�QP��{�\0�@y����r�z&�q�1�ѵ优41�+���+$mb�\n	�\\��i�٨��{tP�i�R��DkՖ�����_�Ġ\Z�h	j��f#B���#@�\n��\\�e�s\\���B�Ď0�8�fA�l�I��h�c�A�\0�:ꊣ�4]�?pa�_9��-<&Rȱ�̾]���@�t�p4�j=����ݼG� M�\'\'\\�pv�Q�]uMf#O�]ꄓ�lw��{(���/��=��A}��e~t�쇹{�Cw���n74����sW}�s�kf+Io����~��z�{�#������놪�:/���A�\0ٿV2v���#��6z�j:�޵��V����E@W�<�y���{ń������[��~,<���⧟�s��sGrv���M�[z!㕌SE}Szlv�^+�o5]����a��F����_�ڣ&�g��<��csHf��y�/��+)g\'��9���4_J+o,=W�¤���V����b�_y�J�W�0��V�\"��?�N�P(�V�-u��I/&~#kＶ��y����%�̨e�o9��c�b?�QLP˜d�5�%%�wy	�q-��I+�r�:N�q���D;{·��7	��̻\"kЇV����1�s��|�q|~299=��O����d\Z�e4M&!��,<���]��');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(30,'3_994e9ae97f27e262','tt_content_4'),
(31,'3_994e9ae97f27e262','pages_2'),
(32,'3_994e9ae97f27e262','pages_3'),
(33,'3_994e9ae97f27e262','pages_4'),
(34,'3_994e9ae97f27e262','sys_file_6'),
(35,'3_994e9ae97f27e262','sys_file_metadata_6'),
(36,'3_994e9ae97f27e262','pageId_3'),
(72,'10_76dee0fa0c23d494','tt_content_10'),
(73,'10_76dee0fa0c23d494','pages_2'),
(74,'10_76dee0fa0c23d494','pages_3'),
(75,'10_76dee0fa0c23d494','pages_4'),
(76,'10_76dee0fa0c23d494','tx_news'),
(77,'10_76dee0fa0c23d494','tx_news_pid_9'),
(78,'10_76dee0fa0c23d494','tx_news_domain_model_news_1'),
(79,'10_76dee0fa0c23d494','tx_news_domain_model_news_2'),
(80,'10_76dee0fa0c23d494','tx_news_domain_model_news_3'),
(81,'10_76dee0fa0c23d494','pages_10'),
(82,'10_76dee0fa0c23d494','pageId_10'),
(83,'10_c0ae31a5ecc50d94','tt_content_10'),
(84,'10_c0ae31a5ecc50d94','pages_2'),
(85,'10_c0ae31a5ecc50d94','pages_3'),
(86,'10_c0ae31a5ecc50d94','pages_4'),
(87,'10_c0ae31a5ecc50d94','tx_news'),
(88,'10_c0ae31a5ecc50d94','tx_news_domain_model_news_1'),
(89,'10_c0ae31a5ecc50d94','tx_news_uid_1'),
(90,'10_c0ae31a5ecc50d94','pages_10'),
(91,'10_c0ae31a5ecc50d94','pageId_10'),
(92,'10_4b78aea429971fcf','tt_content_10'),
(93,'10_4b78aea429971fcf','pages_2'),
(94,'10_4b78aea429971fcf','pages_3'),
(95,'10_4b78aea429971fcf','pages_4'),
(96,'10_4b78aea429971fcf','tx_news'),
(97,'10_4b78aea429971fcf','tx_news_domain_model_news_2'),
(98,'10_4b78aea429971fcf','tx_news_uid_2'),
(99,'10_4b78aea429971fcf','pages_10'),
(100,'10_4b78aea429971fcf','pageId_10');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(24,'10__0_0_1_1',1795278009,'x��VK��6�+�<��~���D�C�ef9Ym5`b��n�濧�l��iW\ZE�Q_Qv�\\�}&h��J	:�ћD[\r���\'�7&X{)�H�O��a�?��=�(���\'�m�9���\rUtZ%���XY��(�U�R���0ڕ>rDQEq-�\0�K�(��I.��i�͘L��H����`�b��`Z2���lWN #y��!]=��bS�ɗ��I��D�N����p9&���T�l�v+YU��!�v}�^��U�� �#�K%H��5��7�-a�FrR��D���j\r��*��WjB\nR�(V���\rEv+��+H�֝-�h��6�w\nj�+�[<�Ǆ�^�5����Sm��k�\\�6��Z�����M�]O�i��I,���s���.\\�&�I�.*SцH��;���\\��\"擗Cc��+�\r=KA�֤�/����q\\��g���WgIJDq�&��]�\0c-�Y�N���JP\n��M]=a�r?j,MKz\\���i%�_!�W�nmS�y�9�ޢ૩)�Kݼp�J{u���.�(C������Bn��Hs�ھٌ̽-x���j��\n\\����V�AR1S]���ԅ�s��n�����O�7N��a�-��ͭ��?����_~��)���\'�W�d��J�ܫbP>[�M�̤-��\'��P�^{w_��6R߲34��?���A6����ݘcg�\"x�jd&��|��2��F�T:7��q���S��~�������Q��rG%s]�1��ͺ9�Xp���ffflTJ��g5���Y�g�T�h���iI�k�pl�b��J�(1L���$:�	�l�[c�B%�]��N�}��F�u)�*{dY8H��\r�[h���f�t�\"�6�{��y5lK�^k9�)�\Z{ۧh���&N��,C4��C���{@���}���,o]�cVޒ�S2^{J�I��W��i����;>%�M�������K2�@���޼��Ǒ��_I��ץҺ�\"��o>�TB+}��t	\ny\'��GQ�����ٚfK̾�&�K�7���۪_��������6%I^��쫘�<)�xK���\'ۜ�\r�ky�'),
(25,'10__0_0_0_0',1795278020,'x��VK��6�+�<��~���D�C�ef9Ym5`b��n�濧�l��iW\ZE�Q_Qv�\\�}&h��J	:�ћD[\r���\'�7&X{)�H�O��a�?��=�(���\'�m�9���\rUtZ%���XY��(�U�R���0ڕ>rDQEq-�\0�K�(��I.��i�͘L��H����`�b��`Z2���lWN #y��!]=��bS�ɗ��I��D�N����p9&���T�l�v+YU��!�v}�^��U�� �#�K%H��5��7�-a�FrR��D���j\r��*��WjB\nR�(V���\rEv+��+H�֝-�h��6�w\nj�+�[<�Ǆ�^�5����Sm��k�\\�6��Z�����M�]O�i��I,���s���.\\�&�I�.*SцH��;���\\��\"擗Cc��+�\r=KA�֤�/����q\\��g���WgIJDq�&��]�\0c-�Y�N���JP\n��M]=a�r?j,MKz\\���i%�_!�W�nmS�y�9�ޢ૩)�Kݼp�J{u���.�(C������Bn��Hs�ھٌ̽-x���j��\n\\����V�AR1S]���ԅ�s��n�����O�7N��a�-��ͭ��?����_~��)���\'�W�d��J�ܫbP>[�M�̤-��\'��P�^{w_��6R߲34��?���A6����ݘcg�\"x�jd&��|��2��F�T:7��q���S��~�������Q��rG%s]�1��ͺ9�Xp���ffflTJ��g5���Y�g�T�h���iI�k�pl�b��J�(1L���$:�	�l�[c�B%�]��N�}��F�u)�*{dY8H��\r�[h���f�t�\"�6�{��y5lK�^k9�)�\Z{ۧh���&N��,C4��C���{@���}���,o]�cVޒ�S2^{J�I��W��i����;>%�M�������K2�@���޼��Ǒ��_I��ץҺ�\"��o>�TB+}��t	\ny\'��GQ�����ٚfK̾�&�K�7���۪_��������6%I^��쫘�<)�xK���\'ۜ�\r�ky�'),
(26,'2__0_0_0_0',1795278020,'x��V�n�6��B�>D[~1��ޢw�z��EW-Q2aITI*���;\"%_�\Z @��j����9�x�_9F��U�5Nz^$�F�3k��4m��V�t}@�Y�eA5s+ڤ�Vv8)X�4����3/\n�:���*��\rs����=NJF*)z�^�\'��O	�y[�)o�-Q�)����%�4m�\0aX�u-򋋌 #uS��m�ӊ[�q\r�FiK:*Y����}�(u�kq���\n^��w�#�]_���\\�%��������4����Y�𛰆�� \'�_�D��M��FZ��I͞�u�i~fD�JE6�G�i+Z�ӚԼ�8L�JHΜ�h5Ԃ�R4dh�-�r@\\��c��57��Zc�@��I<���o7�w=Z�a�o���I!l�v�\nYX�\Z�[����5U�k7tfဩ\\\rdE��(��&��g���ɮ_[�.��u-���m�^����٘�\"�\Z�8�����sG�d�I�2̺z���P��v$?C7�R�?c���R�,Z��P�\Z�?Aa�b�h!�L�¡�/���+�p?$�������BP�}��z��f3u�U�kP;�w�j�W�pL6��ɉ����cƛN�F6|��HF;;��1���(n>,=��H~�����O�_��yu�9���̽�{��b\'&mDa�@��*ܱ����W!�\r�7����K�n�mi ms7��3޲Ҋq=�@�cg�~j�_~��/p2�};�e��>({�C���#iA)S}�q�4����6~���(L� ���0hC@;SD�.�5�qptZO�S��\0�U�(�I�XxO�qzŷ��Ptf+DA��iZ��0�\Z��v0z�[��U�b��Qj�ם;4�L*4\\�V�� ����Ͽ��B��f�l�L�7����ݼ@����G�gx���&^$b����]�ƃ3m�v�w���\"�\n�\n��ކ,��(zf����ʲ���3s�f���к����o��<~��pG������(�G2j��2ꖾ!��o>��B+}�B:A9Ry�_%�Q%���8���{�\"z/Y����$����q�������ݾ�iyX�}Z���rWn�9�BiN��͐�.'),
(27,'3__0_0_0_0',1795278020,'x��XKo�8�+���V�mYRNE[��]_��D��X&\"�Z��c��;$%���Xl�`77�7|g�y@4_�,�oh�M�G�bг2�a���H��b��<PRѦ�@���M�e��j\nQRN���l�\Z�SB�������\0OJ�F�A[�H� ��=^/�0�Nr�X[#7	b�:?}Y�)�[o%S5/�Ǔ#�H�%�i[��28��<���%Ъ,y/\ngc��2��il3`%;���kGG�iO���Z�A�gA8�\'9�ˢ�UW���G�$�aO�#,n��)B�aC4�7���������]���?o��n�>�����˂=y�(��cR�V���A��t����\Zޣ��\"$�z ���#\\���0S�Ўt��V�����@��߫s��l�4�A�u-�����u_���?6�Z��@*	x�G�K?���n�Vy4^?vD	\0���P�\n-��@�kz�S��z������XK�=-�I���k秔���:˩�@y��\n��ߠ�J���Y_z\'�p��*V;SW�Q���f�\r�S���~\0\'�(��)#GH�\'o���R��+����J�BM�L{���g�#H�9�=���*Bg72I4����<GVW\r��<Bu���8Tn;lO�{4��Ǜ���H\nRcNb�sCZ\Z�u_����U�p\\_O-N���ə�^��8b	�������:�-oYAkR��~z	�W�-?AԱ�ԷIR�S���q�Ew�L�����+�(��IW�eߌ\'}3��7�p�E�k}sm�u��7��i�����*Z����V���}	l�Y:]��,2j�J��P�hB�s����~fP��\Z��ϭ4��\n��oPk#]����d\0W7��J����>\0w��g?m3߮�8�&�Ƕ`%WEF�֙Q\Z��g�`�l���wӴ�\Zh�j�]J��%l�����z\0�_.�8�S#\r}�~{�[�/2d��i��@��3Q����Do��D�l7Y8N6�y��o�Cύ��ƹq6Z����H�6R��H�G$r%	Q\'N\n^�M+���W1f�W��h2f����u�^\'��1s��3���r��7�2w�h��������6:��i��7���\"���f�:�s.Z��K�`��]k��yoܽT[�^�-�/�����m������i\\�4̒4J�}B�5����@�x�\"N7!��\r�ŧ'),
(28,'4__0_0_0_0',1795278020,'x��XK��6�+��I��eK{\n��9�����AK�L�$�$�����!)Ҕ,A���O�|��<��q�ϴH�p�ΊgQ$E0�*��Ez���H	HYH!q�+ Z��*ZeIf4%��$N�y��f]i�$��Ь=Ъ\"��\"�S���%�m��|dS{�j��^af�`\\ҮV��zL�g��D�������\0ǐ�ʆ����^$N5��\\4:@�\"h��C=椓�`/����R�b��ՈUt����>[G��^�	�|\'1���b�.��W-���!���\r�psJ4>��گ�\"�7��G���z�:m48��O;V��ՠ��������ׯ���}��r$�,11�b9H?&%�$��9kQ��ԲA\"�\'D۞<��qZ�AT����G=�����dw��jL��=�SO���҄��/;ґw�� �D3��\0��ǖЎ|�DHA���D-���ɘt�`Ξ�^*j�z$9!/��!/!�5��o������<���v?�z��������Yq.\0C���%��|��v�k\"=Lu��6�B�B~�U�Wމ9~�$m�SeTy HU�oC����U0$���?��\nj�ĆGr:2^���k}\0�且S�� �|��؂2���C���M��F*�J7Θ�+�%-b�+���a�&�t���n;$���hd3���Ws%� )P�8���a�Ѯl����-[L�+��C{�4�螸9Yy�VJ����_��8w��%nPC���%���Zm�jAG[��&E%�T��/��Ϻ�3��\'�g]�y�T/@<��L�3^��<��W�s�57����5������xƟqz�?o�y��o��-�f<��h�7�0ɣt�7�h�ٍ7���&�q��\n�{�h#�J����Ȭ�0�����R�<���$���Vn�9�i�OH�D��s#��5¼�k��ZK�����;i��M-��c$�����]���O�����\'�B4��#�.bE�g�46-�\Z��L�ZɻiJ�\Z�e���-ψ�-l�����j\00_��h�TK#��o�h������ګ&����L����(��?�(��*�d�\'Je�jn|�`���h�n������6R��H�F$r)�G�J�m\'nc�3Å13����Ҙ�Fi�m���$L�W3!u��9���|�ܾ��g�c���4jUWh���[�QH�����N`����X�Yr�D��97n_��ע���?-������?N|/�(�	��MY�6Y��6x�K�		ޕ�j�l�dS�Z��'),
(29,'9__0_0_1_1',1795278826,'x��XK��6�+��I��e[{\n��9�{����%+�*I��X��P�(��4	vQ�M�\r9�<8�AI�O$�o�x�OD�#�sC��M/�J�A�bGp�ԭ��ޏv�J��<�Ҹ�4���q�j��9n��\0�c�2!H��E�\r7���b���d���y�Ŏ먅�2A��7��.�FO0�i�pԭ2�s\"*��V=�\r?sT%M�%%F��^gT�۠6a��ӎe�~�;����<��h,\'E1,���M���CF���N�8o�4���e�əvb\rC\r~���R�*)#�+9����b%O{IG���A��O�w��0�X����`M/\\��&��\\���L��3D�(�x���*T�k.G؇:Ĭ��)+�r�`����:n�h�i������:O\n��sJ���������o������\"�j/�]N�\nFkd�	�S��=�|�#\"u�[�,����I�����V��(�_7����KW6���}U�t|n�=��dG	����*-A��՘4���\\p��k�nm\0?M����a?�H0�!Q���n% \08��뺶|�j�⾣�.m!��\nT�< ㅶ�S0T��x���6���m�UпℋO�l[�e���R���)�����5�����P�q²�me������O��\\Gד-sٺ���dB�d�	0h�� ��!��P��O#@8��(�[3u��	C�BՐ,����5(+JcԳv6�o�J��YדOc�iz����t�@(,��]J�����n7>��}�c�ʼ6�!YR��4��Ch�8Znx-m\0���e�j�q\"���us�ƅQ�e	ˍ�Y���x�\'��[�n��µ�z7��{���:޵S���o���N�U���-G�y�JR���֯����E�����&e��\"�Kq�95��R��y��Q��;�[R���K��(���\Z�u��!b$�ۘ�$�;Qu�A�-�g���3$��\0���L�S�qMp�f�m|�J��\"tjZ~�{3m2d���WM s�F������kd�ޜ?�𗤇��\r�p� �	s�������8�q�\\/�4\ZG\ni��?���j_�!%;�)!q�(�UW7�x����\\ζ��\\��54�]��ބf�k43��0ڭ���\r�W��������H2GOq��1�}�U��Tƨ��k�PJi��09�^��~�x�5_���w6����s��{7O�(��t3kQ\ZDa��9.\n����<�����');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(59,'10__0_0_1_1','pageId_1'),
(60,'10__0_0_1_1','pageId_10'),
(61,'10__0_0_0_0','pageId_1'),
(62,'10__0_0_0_0','pageId_10'),
(63,'2__0_0_0_0','pageId_1'),
(64,'2__0_0_0_0','pageId_2'),
(65,'3__0_0_0_0','pageId_1'),
(66,'3__0_0_0_0','pageId_2'),
(67,'3__0_0_0_0','pageId_3'),
(68,'4__0_0_0_0','pageId_1'),
(69,'4__0_0_0_0','pageId_2'),
(70,'4__0_0_0_0','pageId_3'),
(71,'4__0_0_0_0','pageId_4'),
(72,'9__0_0_1_1','pageId_1'),
(73,'9__0_0_1_1','pageId_2'),
(74,'9__0_0_1_1','pageId_9');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1792414468,1792413041,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,1,1792414468,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1792603914,1792415046,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1792675900,0,0,0,0,0.5,1,'Meine Testseite','/meine-testseite','',0,0,0,0,'',0,'','','',0,0,0,'',0,0,'','','','','',0,0,0,'',0,'pagets__two_columns','','','',0,0,'','','','',0,'','',0,''),
(3,2,1792519997,1792500897,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,19,0,1792519997,0,0,0,0,0.5,1,'Ebene 2','/meine-testseite/ebene-2','',0,0,0,0,'',0,'','','',0,0,0,'',0,0,'','','','','',0,0,0,'',0,'','','','',0,0,'','','','',0,'','',0,''),
(4,3,1792515636,1792500939,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,19,0,1792520063,0,0,0,0,0.5,1,'Ebene 3','/meine-testseite/ebene-2/ebene-3','',0,0,0,0,'',0,'','','',0,0,0,'',0,0,'','','','','',0,0,0,'',0,'','','','',0,0,'','','','',0,'','',0,''),
(5,3,1792515636,1792511183,0,0,0,0,'',256,NULL,0,1,4,4,'{\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"canonical_link\":\"\",\"categories\":\"0\",\"content_from_pid\":\"0\",\"description\":\"\",\"doktype\":\"1\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"hidden\":\"0\",\"is_siteroot\":\"0\",\"keywords\":\"\",\"l10n_source\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"nav_title\":\"\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_description\":\"\",\"og_image\":\"0\",\"og_title\":\"\",\"php_tree_stop\":\"0\",\"rowDescription\":\"\",\"seo_title\":\"\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"slug\":\"\\/meine-testseite\\/ebene-2\\/ebene-3\",\"starttime\":\"0\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"Ebene 3\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"0\",\"twitter_title\":\"\",\"url\":\"\"}',0,0,0,0,1,1,31,19,0,1792515636,0,0,0,0,0.5,1,'Ebene Drei','/meine-testseite/ebene-2/translate-to-german-ebene-3','',0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(6,2,1792519994,1792516782,0,1,0,0,'',256,NULL,0,1,3,3,'{\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"starttime\":\"parent\",\"endtime\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}','{\"TSconfig\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"0\",\"content_from_pid\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"extendToSubpages\":\"0\",\"is_siteroot\":\"0\",\"l10n_source\":\"0\",\"l18n_cfg\":\"0\",\"lastUpdated\":\"0\",\"layout\":\"0\",\"media\":\"0\",\"module\":\"\",\"mount_pid\":\"0\",\"mount_pid_ol\":\"0\",\"nav_hide\":\"0\",\"newUntil\":\"0\",\"no_follow\":\"0\",\"no_index\":\"0\",\"no_search\":\"0\",\"og_image\":\"0\",\"php_tree_stop\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"slug\":\"\\/meine-testseite\\/ebene-2\",\"starttime\":\"0\",\"target\":\"\",\"title\":\"Ebene 2\",\"tsconfig_includes\":\"\",\"twitter_image\":\"0\",\"url\":\"\"}',0,0,0,0,1,1,31,19,0,0,0,0,0,0,0.5,1,'[Translate to German:] Ebene 2','/meine-testseite/translate-to-german-ebene-2',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(9,2,1792683233,1792683074,0,1,0,0,'0',128,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"categories\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"hidden\":\"\",\"media\":\"\",\"module\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,0,0.5,254,'News-Speicher','/meine-testseite/news-speicher',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'news',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),
(10,1,1792685118,1792684527,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1792686009,0,0,0,0,0.5,1,'News Detail','/news-detail','',0,0,0,0,'',1,'','','',0,0,0,'',0,0,'','','','','',0,0,0,'',0,'','','','',0,0,'','','','',0,'','',0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1792416029,1792416029,'/_temp_/index.html','1cd5eec12b9b11599c0b4c6b2d43342c4fb53a7b','0258f8a5f703dd44c350fbfcddeecb1634d46ad4','html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',1792412475,1792412475,116,1,1,'text/html',0,0),
(2,0,1792416032,1792416032,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1792412475,1792412475,0,1,5,'application/x-empty',0,0),
(3,0,1792416035,1792416035,'/user_upload/_temp_/index.html','a3ef597b554ed2a28c720b3e90e51edc9ec642b1','4e0743c93934dd9a02564d8e654d714bd2dc3d20','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1792412475,1792412475,0,1,5,'application/x-empty',0,0),
(4,0,1792416036,1792416036,'/user_upload/_temp_/importexport/index.html','68614dc2826769e93d8a8ead62af30ac99aaa83a','0795cf796b4fc959be0ec00b183c0f47609dd9a5','html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',1792412475,1792412475,116,1,1,'text/html',0,0),
(5,0,1792416443,1792416443,'/images/leipzig.jpg','cc670794c4152c93e2bbb8cea5e8f97851387f73','c1a406ab82b5588738d1587da2761746ec584a6c','jpg','leipzig.jpg','003677c71b9db471e05952bd368aa4ad78488793',1792416442,1792416442,933259,1,2,'image/jpeg',0,0),
(6,0,1792501901,1792501901,'/images/sanda.jpeg','df67b7685cf2ef0962ae176418c5cb15e0adfc51','c1a406ab82b5588738d1587da2761746ec584a6c','jpeg','sanda.jpeg','321608813abb935e664089f158fd27554b15d1f1',1792501901,1792501901,64886,1,2,'image/jpeg',0,0),
(7,0,1792503201,1792503201,'/audio/example.ogg','5d4d8bd21c98aee178503e59cfa5cf7323352911','958bd2aaee8c187a3aad96bf4bcb2504b66bcfa3','ogg','example.ogg','97791e6d85fa9ed7d583acc0c85d23cecf084d27',1792503201,1792503201,104793,1,3,'audio/ogg',0,0),
(8,0,1792674803,1792674803,'/user_upload/leipzig2.jpeg','b4de17b3f208a9286d5f64571691be6c9a8b25d9','19669f1e02c2f16705ec7587044c66443be70725','jpeg','leipzig2.jpeg','3e3356b3ac1ad366356664b68b054e88e347d16a',1792674803,1792674803,599991,1,2,'image/jpeg',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1792416029,1792416029,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0),
(2,0,1792416032,1792416032,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,0,0),
(3,0,1792416035,1792416035,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,0,0),
(4,0,1792416036,1792416036,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,0,0),
(5,0,1792416442,1792416442,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,2185,1616),
(6,0,1792501901,1792501901,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,640,640),
(7,0,1792503201,1792503201,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,0,0),
(8,0,1792674803,1792674803,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,1920,1080);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1792416443,1792416443,1,5,'/_processed_/8/7/csm_leipzig_109bd7a527.jpg','csm_leipzig_109bd7a527.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','003677c71b9db471e05952bd368aa4ad78488793','Image.CropScaleMask','109bd7a527',155,115),
(2,1792416447,1792416447,1,5,'/_processed_/8/7/csm_leipzig_6503f95603.jpg','csm_leipzig_6503f95603.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','003677c71b9db471e05952bd368aa4ad78488793','Image.CropScaleMask','6503f95603',203,150),
(3,1792416447,1792416447,1,5,'/_processed_/8/7/csm_leipzig_233327e43d.jpg','csm_leipzig_233327e43d.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','003677c71b9db471e05952bd368aa4ad78488793','Image.CropScaleMask','233327e43d',61,45),
(4,1792416531,1792416531,1,5,'/_processed_/8/7/csm_leipzig_b4a59b2a40.jpg','csm_leipzig_b4a59b2a40.jpg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','003677c71b9db471e05952bd368aa4ad78488793','Image.CropScaleMask','b4a59b2a40',64,47),
(5,1792416538,1792416538,1,5,'/_processed_/8/7/csm_leipzig_0ceff0db41.jpg','csm_leipzig_0ceff0db41.jpg',NULL,'a:3:{s:5:\"width\";i:300;s:6:\"height\";i:221;s:4:\"crop\";N;}','77678b50ca5ed21f616dd5b446ac920faa2686d5','003677c71b9db471e05952bd368aa4ad78488793','Image.CropScaleMask','0ceff0db41',300,221),
(6,1792501901,1792501901,1,6,'/_processed_/a/5/csm_sanda_372e3830fe.jpeg','csm_sanda_372e3830fe.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','321608813abb935e664089f158fd27554b15d1f1','Image.CropScaleMask','372e3830fe',115,115),
(7,1792501902,1792501902,1,6,'/_processed_/a/5/csm_sanda_1c4d1c1bab.jpeg','csm_sanda_1c4d1c1bab.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','321608813abb935e664089f158fd27554b15d1f1','Image.CropScaleMask','1c4d1c1bab',150,150),
(8,1792501902,1792501902,1,6,'/_processed_/a/5/csm_sanda_99b2b30ef8.jpeg','csm_sanda_99b2b30ef8.jpeg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','321608813abb935e664089f158fd27554b15d1f1','Image.CropScaleMask','99b2b30ef8',45,45),
(9,1792501921,1792501920,1,6,'/_processed_/a/5/csm_sanda_a02cf6a38b.jpeg','csm_sanda_a02cf6a38b.jpeg','','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','321608813abb935e664089f158fd27554b15d1f1','Image.CropScaleMask','a02cf6a38b',64,64),
(10,1792501933,1792501933,1,6,'/_processed_/a/5/csm_sanda_b74ecbf301.jpeg','csm_sanda_b74ecbf301.jpeg',NULL,'a:3:{s:5:\"width\";i:300;s:6:\"height\";i:300;s:4:\"crop\";N;}','925a73bcbee0c1bbe935227b73627233497979d6','321608813abb935e664089f158fd27554b15d1f1','Image.CropScaleMask','b74ecbf301',300,300),
(11,1792503201,1792503201,1,7,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','97791e6d85fa9ed7d583acc0c85d23cecf084d27','Image.CropScaleMask','3c543617fb',0,0),
(12,1792503209,1792503209,1,7,'',NULL,'','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','97791e6d85fa9ed7d583acc0c85d23cecf084d27','Image.CropScaleMask','d91488f7ce',0,0),
(13,1792503243,1792503243,1,7,'',NULL,'','a:2:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;}','adce1dbae2e4683670473874bda4b4e3a0297998','97791e6d85fa9ed7d583acc0c85d23cecf084d27','Image.CropScaleMask','667ff7d52e',0,0),
(14,1792603923,1792603923,1,5,'/_processed_/8/7/csm_leipzig_27a58c2fcb.jpg','csm_leipzig_27a58c2fcb.jpg',NULL,'a:3:{s:5:\"width\";i:600;s:6:\"height\";i:443;s:4:\"crop\";N;}','7fed5698370220c12285efe4687790cfbfaf2acd','003677c71b9db471e05952bd368aa4ad78488793','Image.CropScaleMask','27a58c2fcb',600,443),
(15,1792675094,1792674803,1,8,'/_processed_/a/a/preview_leipzig2_bede58deb1.jpeg','preview_leipzig2_bede58deb1.jpeg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','3e3356b3ac1ad366356664b68b054e88e347d16a','Image.Preview','bede58deb1',64,36),
(16,1792674806,1792674803,1,8,'/_processed_/a/a/csm_leipzig2_b35e0abc39.jpeg','csm_leipzig2_b35e0abc39.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','3e3356b3ac1ad366356664b68b054e88e347d16a','Image.CropScaleMask','b35e0abc39',267,150),
(17,1792674803,1792674803,1,8,'/_processed_/a/a/csm_leipzig2_1328b79d32.jpeg','csm_leipzig2_1328b79d32.jpeg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','3e3356b3ac1ad366356664b68b054e88e347d16a','Image.CropScaleMask','1328b79d32',80,45),
(18,1792675119,1792675119,1,8,'/_processed_/a/a/csm_leipzig2_440a1545bc.jpeg','csm_leipzig2_440a1545bc.jpeg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c447b923fbee8b7b0021133753512eb372dc7e4f','3e3356b3ac1ad366356664b68b054e88e347d16a','Image.CropScaleMask','440a1545bc',400,225);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,2,1792603606,1792416528,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,5,NULL,NULL,3,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(2,3,1792501918,1792501918,0,0,0,0,NULL,'',0,0,0,0,6,NULL,NULL,4,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(3,4,1792520318,1792503239,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,NULL,5,'tt_content','assets',1,'',NULL,NULL,0,0),
(4,4,1792520318,1792511506,0,0,1,3,NULL,'{\"alternative\":\"\",\"autoplay\":\"0\",\"crop\":\"\",\"description\":\"\",\"fieldname\":\"assets\",\"hidden\":\"0\",\"link\":\"\",\"sorting_foreign\":\"1\",\"tablenames\":\"tt_content\",\"title\":\"\",\"uid_foreign\":\"5\",\"uid_local\":\"7\"}',0,0,0,0,7,NULL,NULL,6,'tt_content','assets',1,'',NULL,NULL,0,0),
(7,2,1792674815,1792674815,0,0,0,0,NULL,'',0,0,0,0,8,NULL,NULL,0,'tt_content','meinsitepackage_teasercard_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(8,2,1792675900,1792675111,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,8,NULL,NULL,9,'tt_content','meinsitepackage_teasercard_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1792413329,1792413329,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1792414464,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":null},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$M2RJEC6AbWbLTZDJwhmQozX4PMM4GmWi:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1792414468,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$4Y5Wh5AyEGWf9lS2f0xIrirlApXqiG-W:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1792415046,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/meine-testseite\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Meine Testseite\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"sitemap_changefreq\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"0\",\"no_search\":\"0\",\"php_tree_stop\":\"0\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"0\",\"nav_hide\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"sys_language_uid\":0,\"crdate\":1792415046,\"t3ver_stage\":0,\"tstamp\":1792415046,\"uid\":2}',0,'0400$z5NA9RsZ9BQtTcbKqiZywkxlNvLf86m7:f11830df10b4b0bca2db34810c2241b3'),
(4,1792415058,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Ql58ujHJXynJU0-a_zaARnPBOA9pXCxc:f11830df10b4b0bca2db34810c2241b3'),
(5,1792415543,1,'BE',1,0,1,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"Erstes Element\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<\\/p>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792415543,\"t3ver_stage\":0,\"tstamp\":1792415543,\"uid\":1}',0,'0400$0cWWdW4ldhRWU17AAwzyJ_bpLieTsBmZ:7fa2c035f26826fe83eeecaaeddc4d40'),
(6,1792415556,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$52mIZBNSGvnoYT3t6uhGlCOogOTwmoB3:7fa2c035f26826fe83eeecaaeddc4d40'),
(7,1792415738,1,'BE',1,0,2,'tt_content','{\"CType\":\"header\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":512,\"sys_language_uid\":0,\"header\":\"Zweites Element\",\"header_link\":\"\",\"subheader\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792415738,\"t3ver_stage\":0,\"tstamp\":1792415738,\"uid\":2}',0,'0400$qF-DrZaEatvh-Pd2UQVKsdS-fOj-MfB7:01dbc21fdb1263685b9147b3b1596ea8'),
(8,1792416528,1,'BE',1,0,3,'tt_content','{\"CType\":\"textpic\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"18\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":768,\"sys_language_uid\":0,\"header\":\"Drittes Element ist ein Bild mit Text\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<\\/p>\",\"imageborder\":\"0\",\"image_zoom\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792416528,\"t3ver_stage\":0,\"tstamp\":1792416528,\"uid\":3}',0,'0400$DgEdCzcXLNUeKVnrQdC43-cCkKQmvqSz:b92300cfb5d1d3645c9cb212a7f56c1f'),
(9,1792416528,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"5\",\"sys_language_uid\":0,\"crdate\":1792416528,\"t3ver_stage\":0,\"tstamp\":1792416528,\"uid\":1}',0,'0400$DgEdCzcXLNUeKVnrQdC43-cCkKQmvqSz:4cf496f597e7b095ce8b755e6cec3c0c'),
(10,1792500897,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/meine-testseite\\/ebene-2\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Ebene 2\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"sitemap_changefreq\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"0\",\"no_search\":\"0\",\"php_tree_stop\":\"0\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"0\",\"nav_hide\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"sys_language_uid\":0,\"crdate\":1792500897,\"t3ver_stage\":0,\"tstamp\":1792500897,\"uid\":3}',0,'0400$CUaVn1UezT9P5dl3fxe8moE6hx_hSXHm:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(11,1792500909,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$FFyebrrroX4psjWpiQWTyLb8dX86IKa3:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(12,1792500939,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/meine-testseite\\/ebene-2\\/ebene-3\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":3,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Ebene 3\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"sitemap_changefreq\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"0\",\"no_search\":\"0\",\"php_tree_stop\":\"0\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"0\",\"nav_hide\":\"0\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"sys_language_uid\":0,\"crdate\":1792500939,\"t3ver_stage\":0,\"tstamp\":1792500939,\"uid\":4}',0,'0400$tUlJNsCE5ak6r18019xvzPJF5tGroKVM:412add0b3eb6ec8f1cb6710aea92e21e'),
(13,1792500945,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$I_8dfOLycunoDDbUZE2Bxzwl0vCU4bui:412add0b3eb6ec8f1cb6710aea92e21e'),
(14,1792501671,1,'BE',1,0,4,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"Sanda Island Lighthouse\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p><i>From Wikipedia, the free encyclopedia<\\/i><\\/p>\\r\\n<p>The Sanda Island Lighthouse is a lighthouse on Sanda Island, Argyll and Bute, United Kingdom.<\\/p>\\r\\n<p>One of the thirteen major lighthouses designed and built by Alan Stevenson, the lighthouse was established in 1850, after a series of shipwrecks in the area. The three \\\"steps\\\" of the lighthouse were due to the cliff on which it was built, and remains a unique design in Scotland.<\\/p>\\r\\n<p>Automated in 1991, the lighthouse is operated by the Northern Lighthouse Board, and designated a Category A listed building.<\\/p>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792501671,\"t3ver_stage\":0,\"tstamp\":1792501671,\"uid\":4}',0,'0400$6-zibKRp2DNmLgThPrWcVgK0rl4I7GdT:4d391f5ef79b8d5d10dffa8a07ca167d'),
(15,1792501842,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$xLwYMA2idJu_A6JRXRi5NRjACXw8D4A6:4d391f5ef79b8d5d10dffa8a07ca167d'),
(16,1792501864,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"CType\":\"text\"},\"newRecord\":{\"CType\":\"textpic\"}}',0,'0400$s2Gll_-aYtp3-XQlXOu8z7YlowG3IV4F:4d391f5ef79b8d5d10dffa8a07ca167d'),
(17,1792501918,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"imageorient\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"imageorient\":\"17\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$Wsd35wrzj2fCh7nrOLyb9_H9A4Xstdsb:4d391f5ef79b8d5d10dffa8a07ca167d'),
(18,1792501918,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1792501918,\"t3ver_stage\":0,\"tstamp\":1792501918,\"uid\":2}',0,'0400$Wsd35wrzj2fCh7nrOLyb9_H9A4Xstdsb:814fc0f720dfab882655a795e23a5b66'),
(19,1792501918,2,'BE',1,0,4,'tt_content','{\"oldRecord\":{\"imageorient\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"imageorient\":\"17\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$Wsd35wrzj2fCh7nrOLyb9_H9A4Xstdsb:4d391f5ef79b8d5d10dffa8a07ca167d'),
(20,1792503239,1,'BE',1,0,5,'tt_content','{\"CType\":\"textmedia\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"8\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"Ogg\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\"ogging,\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\/p>\",\"imageborder\":\"0\",\"image_zoom\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792503239,\"t3ver_stage\":0,\"tstamp\":1792503239,\"uid\":5}',0,'0400$lIceNQkr9QwZI3ECLR26gDQjhzvOqGqs:c7626fc9bcba6f70beb6ebc085a400db'),
(21,1792503239,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":\"0\",\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1792503239,\"t3ver_stage\":0,\"tstamp\":1792503239,\"uid\":3}',0,'0400$lIceNQkr9QwZI3ECLR26gDQjhzvOqGqs:d2c609347a4764200256b39b9425159a'),
(22,1792511183,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/meine-testseite\\/ebene-2\\/translate-to-german-ebene-3\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"4\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\\\\/ebene-3\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Ebene 3\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"url\\\":\\\"\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":3,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":4,\"title\":\"[Translate to German:] Ebene 3\",\"nav_hide\":0,\"no_search\":0,\"author\":\"\",\"author_email\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":0,\"extendToSubpages\":0,\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"editlock\":0,\"no_index\":0,\"no_follow\":0,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"url\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1792511183,\"t3ver_stage\":0,\"tstamp\":1792511183,\"uid\":5}',0,'0400$YeJykkiaugsJHp88VRertKgwTjEGu5VI:7ef5a4e3e11db8ac3fea4d7a75468161'),
(23,1792511401,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"title\":\"[Translate to German:] Ebene 3\"},\"newRecord\":{\"title\":\"Ebene Drei\"}}',0,'0400$UErCCBetbyLU_SZjfVRlAi-NfLYoulTV:7ef5a4e3e11db8ac3fea4d7a75468161'),
(24,1792511438,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\\\\/ebene-3\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Ebene 3\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"url\\\":\\\"\\\"}\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"1\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"0\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"0.5\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\\\\/ebene-3\\\",\\\"starttime\\\":\\\"0\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Ebene 3\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"twitter_title\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"}}',0,'0400$AmDHFE8WDzYJlL3NibbAKyHbbSQs_trJ:7ef5a4e3e11db8ac3fea4d7a75468161'),
(25,1792511506,1,'BE',1,0,4,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"assets\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"5\\\",\\\"uid_local\\\":\\\"7\\\"}\",\"pid\":4,\"sys_language_uid\":1,\"l10n_state\":null,\"uid_local\":\"7\",\"uid_foreign\":5,\"tablenames\":\"tt_content\",\"fieldname\":\"assets\",\"link\":\"\",\"crop\":null,\"crdate\":1792511506,\"t3ver_stage\":0,\"tstamp\":1792511506,\"uid\":4}',0,'0400$cynBnzxvl0a-A32IfgkgNnOv9qS1Xpqk:cea5fcd7b97871880cfe3717d6b52ef4'),
(26,1792511506,1,'BE',1,0,6,'tt_content','{\"CType\":\"textmedia\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"8\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":\"5\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textmedia\\\",\\\"assets\\\":\\\"1\\\",\\\"bodytext\\\":\\\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\\\\\"ogging,\\\\\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Ogg\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"0\\\",\\\"imageorient\\\":\\\"8\\\",\\\"imagewidth\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"list_type\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":512,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":1,\"l10n_source\":5,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"[Translate to German:] Ogg\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>[Translate to German:] Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\"ogging,\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\/p>\",\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"crdate\":1792511506,\"t3ver_stage\":0,\"tstamp\":1792511506,\"uid\":6}',0,'0400$fY3e_ucedtTSu20QjUhmuVuYLadq9D6R:c0db6803ab1ec5f70c36e2a72187867b'),
(27,1792511516,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$olc9N7KjqtY4hZTuRDqT-Tf8yhdF7Y8S:7ef5a4e3e11db8ac3fea4d7a75468161'),
(28,1792511702,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>[Translate to German:] Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\"ogging,\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\/p>\"},\"newRecord\":{\"bodytext\":\"<p>Ogg ist ein digitales Multimedia-Containerformat, das f\\u00fcr ein effizientes Streaming sowie die Bearbeitung digitaler Multimedia-Inhalte konzipiert wurde. Es wird von der Xiph.Org Foundation gepflegt, ist frei und offen sowie frei von Softwarepatenten. Der Name leitet sich von \\u201eogging\\u201c ab \\u2013 einem Fachbegriff aus dem Computerspiel Netrek[4] \\u2013, was auf den hohen Rechenaufwand der fr\\u00fchen Versionen dieser Software anspielt.<\\/p>\"}}',0,'0400$NV-DCsEg644a26WkFI7roRo2TTEdDwPg:c0db6803ab1ec5f70c36e2a72187867b'),
(29,1792511816,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"header\":\"[Translate to German:] Ogg\"},\"newRecord\":{\"header\":\"Ogg\"}}',0,'0400$NMsb-X6ggCSYcKttqsFMBxBqqyReW6aI:c0db6803ab1ec5f70c36e2a72187867b'),
(30,1792512763,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$IuqaRJHxl5sDbguuTFg99cebCKpx_YeG:c0db6803ab1ec5f70c36e2a72187867b'),
(31,1792515127,1,'BE',1,0,1,'be_groups','{\"file_permissions\":\"readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile\",\"workspace_perms\":0,\"hidden\":\"0\",\"pid\":0,\"title\":\"Testgruppe\",\"subgroup\":\"\",\"pagetypes_select\":\"1\",\"tables_modify\":\"pages,tt_content\",\"tables_select\":\"pages,tt_content\",\"non_exclude_fields\":\"\",\"explicit_allowdeny\":\"\",\"allowed_languages\":\"\",\"groupMods\":\"web_layout,web_list\",\"availableWidgets\":\"\",\"mfa_providers\":\"\",\"db_mountpoints\":\"3\",\"file_mountpoints\":\"\",\"category_perms\":0,\"TSconfig\":\"\",\"description\":\"\",\"crdate\":1792515127,\"tstamp\":1792515127,\"uid\":1}',0,'0400$aUY_hA_JlGFfw-HX-JDW0LmQ8ZmB3soX:aaa64c362c09328e0a5e7f9389b01256'),
(32,1792515636,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"perms_groupid\":0,\"perms_group\":27},\"newRecord\":{\"perms_groupid\":1,\"perms_group\":19}}',0,'0400$MNMwO8q6-E76H6fi8MSXQr2l3j1R_ymQ:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(33,1792515636,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"perms_groupid\":0,\"perms_group\":27},\"newRecord\":{\"perms_groupid\":1,\"perms_group\":19}}',0,'0400$MNMwO8q6-E76H6fi8MSXQr2l3j1R_ymQ:412add0b3eb6ec8f1cb6710aea92e21e'),
(34,1792515636,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"perms_groupid\":0,\"perms_group\":27},\"newRecord\":{\"perms_groupid\":1,\"perms_group\":19}}',0,'0400$MNMwO8q6-E76H6fi8MSXQr2l3j1R_ymQ:7ef5a4e3e11db8ac3fea4d7a75468161'),
(35,1792515895,1,'BE',1,0,2,'be_users','{\"admin\":\"0\",\"options\":\"3\",\"file_permissions\":\"readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile\",\"workspace_perms\":1,\"lang\":\"default\",\"lastlogin\":0,\"disable\":\"1\",\"starttime\":0,\"endtime\":0,\"pid\":0,\"username\":\"willi\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$TUw4VUtGL3AzWTlJOFlFZQ$BNdrFarqHThObBzl345esI5Cpk6kPbkPHa7m0IHiVZ0\",\"usergroup\":\"1\",\"realName\":\"Willi\",\"email\":\"\",\"userMods\":\"\",\"allowed_languages\":\"\",\"db_mountpoints\":\"\",\"file_mountpoints\":\"\",\"category_perms\":0,\"TSconfig\":\"\",\"description\":\"\",\"crdate\":1792515895,\"tstamp\":1792515895,\"uid\":2}',0,'0400$UUZUJmZ2yExYo4WxqxEjTJRZ8rJxByts:c98a59192960d7c1b8e415cda9ffe933'),
(36,1792516289,2,'BE',1,0,2,'be_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$TUw4VUtGL3AzWTlJOFlFZQ$BNdrFarqHThObBzl345esI5Cpk6kPbkPHa7m0IHiVZ0\"},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$QU5GSWhlLjdvdk9YZDFCUw$rHCMr\\/OH0IuWfzmaTv6UGK67Y6k2EKvqIrv9Th67W6g\"}}',0,'0400$EBgXZAq_cE1-R7jmmMbxwrdBWEh7HXAV:c98a59192960d7c1b8e415cda9ffe933'),
(37,1792516365,2,'BE',1,0,2,'be_users','{\"oldRecord\":{\"disable\":1},\"newRecord\":{\"disable\":\"0\"}}',0,'0400$e-zOpBZhCrYJSDZmEm7kYJz8-6u59OJa:c98a59192960d7c1b8e415cda9ffe933'),
(38,1792516726,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"title\":\"Ebene 2\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Ebene 23\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"}}',0,'0400$wtqgHB8ypCLsLCWh52SIeatVddpZJqTC:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(39,1792516732,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"title\":\"Ebene 23\"},\"newRecord\":{\"title\":\"Ebene 2\"}}',0,'0400$-xYYk7qfH78nvGEGz5nDaX40JZWPHQ0g:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(40,1792516782,1,'BE',2,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/meine-testseite\\/translate-to-german-ebene-2\",\"categories\":0,\"layout\":0,\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":0,\"shortcut\":0,\"shortcut_mode\":0,\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":\"3\",\"l10n_diffsource\":\"{\\\"l10n_source\\\":\\\"0\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\",\\\"title\\\":\\\"Ebene 2\\\",\\\"url\\\":\\\"\\\"}\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":19,\"perms_everybody\":0,\"sys_language_uid\":1,\"l10n_source\":3,\"title\":\"[Translate to German:] Ebene 2\",\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"url\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"crdate\":1792516782,\"t3ver_stage\":0,\"tstamp\":1792516782,\"uid\":6}',0,'0400$ERKe449zVv7KrrAijmGFik7XAvFVpdRl:c75354c439a48dbde16b03ac553a080d'),
(41,1792517281,2,'BE',1,0,1,'be_groups','{\"oldRecord\":{\"non_exclude_fields\":\"\"},\"newRecord\":{\"non_exclude_fields\":\"pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:cache_timeout,pages:cache_tags,pages:canonical_link,pages:categories,pages:sitemap_changefreq,pages:module,pages:rowDescription,pages:description,pages:author_email,pages:hidden,pages:media,pages:no_follow,pages:layout,pages:php_tree_stop,pages:no_search,pages:extendToSubpages,pages:no_index,pages:is_siteroot,pages:keywords,pages:lastUpdated,pages:l18n_cfg,pages:mount_pid_ol,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:sitemap_priority,pages:shortcut_mode,pages:content_from_pid,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:doktype,pages:twitter_card,pages:twitter_description,pages:twitter_image,pages:twitter_title,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:uploads_description,tt_content:uploads_type,tt_content:hidden,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:imagewidth\"}}',0,'0400$6dwfCpj_bAdVZp5l4NYuh0mn_8gxQDaA:aaa64c362c09328e0a5e7f9389b01256'),
(42,1792518004,2,'BE',1,0,1,'be_groups','{\"oldRecord\":{\"explicit_allowdeny\":\"\"},\"newRecord\":{\"explicit_allowdeny\":\"tt_content:CType:header,tt_content:CType:text,tt_content:CType:list,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:shortcut,tt_content:CType:div,tt_content:CType:html,tt_content:CType:form_formframework,tt_content:CType:felogin_login\"}}',0,'0400$Y9KSK24U9gcWZ3ELTVT_m-EANPcY3qOb:aaa64c362c09328e0a5e7f9389b01256'),
(43,1792519812,1,'BE',1,0,1,'sys_workspace','{\"publish_time\":0,\"freeze\":\"0\",\"live_edit\":\"0\",\"previewlink_lifetime\":48,\"stagechg_notification\":\"1\",\"edit_allow_notificaton_settings\":\"3\",\"edit_notification_preselection\":\"2\",\"publish_allow_notificaton_settings\":\"3\",\"publish_notification_preselection\":\"1\",\"execute_allow_notificaton_settings\":\"3\",\"execute_notification_preselection\":\"3\",\"pid\":0,\"title\":\"MeinSpace\",\"adminusers\":\"\",\"members\":\"\",\"edit_notification_defaults\":\"\",\"publish_notification_defaults\":\"\",\"execute_notification_defaults\":\"\",\"db_mountpoints\":\"\",\"publish_access\":\"0\",\"description\":\"\",\"tstamp\":1792519812,\"uid\":1}',0,'0400$I8hu4W3ZeHYoBwSaw-wGBxY7QzT0vCgv:0e21ebd1c50ad25dc82a43bb769d61ef'),
(44,1792519994,1,'BE',1,0,3,'pages','{\"pid\":2,\"tstamp\":1792519994,\"crdate\":1792519994,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\",\"t3ver_oid\":3,\"t3ver_wsid\":1,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":19,\"perms_everybody\":0,\"SYS_LASTCHANGED\":1792516732,\"shortcut\":0,\"content_from_pid\":0,\"mount_pid\":0,\"tx_impexp_origuid\":0,\"sitemap_priority\":\"0.5\",\"doktype\":\"1\",\"title\":\"Ebene 2\",\"slug\":\"\\/meine-testseite\\/ebene-2\",\"TSconfig\":\"\",\"php_tree_stop\":0,\"categories\":\"0\",\"layout\":\"0\",\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"url\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"no_search\":0,\"shortcut_mode\":\"0\",\"keywords\":\"\",\"description\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"media\":0,\"is_siteroot\":0,\"mount_pid_ol\":0,\"module\":\"\",\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"twitter_card\":\"\",\"uid\":7,\"workspace\":1}',1,'0400$L_Z6QgTqWoAnurTn4VZfHWileuojlnIR:df50bb24cbce671cf0d61f42fbbef601'),
(45,1792519994,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"workspace\":1}',1,'0400$9vcTf1EXzQRtfa7VnD7gn0SLUDbt9pWC:df50bb24cbce671cf0d61f42fbbef601'),
(46,1792519994,1,'BE',1,0,6,'pages','{\"pid\":2,\"tstamp\":1792519994,\"crdate\":1792519994,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_parent\":\"3\",\"l10n_source\":3,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"url\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"l10n_diffsource\":\"{\\\"l10n_source\\\":\\\"0\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\",\\\"title\\\":\\\"Ebene 2\\\",\\\"url\\\":\\\"\\\"}\",\"t3ver_oid\":6,\"t3ver_wsid\":1,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":19,\"perms_everybody\":0,\"SYS_LASTCHANGED\":0,\"shortcut\":0,\"content_from_pid\":0,\"mount_pid\":0,\"tx_impexp_origuid\":0,\"sitemap_priority\":\"0.5\",\"doktype\":\"1\",\"title\":\"[Translate to German:] Ebene 2\",\"slug\":\"\\/meine-testseite\\/translate-to-german-ebene-2\",\"TSconfig\":null,\"php_tree_stop\":0,\"categories\":\"0\",\"layout\":\"0\",\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"url\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"no_search\":0,\"shortcut_mode\":\"0\",\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"media\":0,\"is_siteroot\":0,\"mount_pid_ol\":0,\"module\":\"\",\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"\",\"uid\":8,\"workspace\":1}',1,'0400$k2QIQfmU9nCVA3MpIzTP4ruoNDzvAzpE:595375f2fb9f014e091eb08fbc51ec88'),
(47,1792519994,2,'BE',1,0,6,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"l10n_source\\\":\\\"0\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\",\\\"title\\\":\\\"Ebene 2\\\",\\\"url\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Ebene 2\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"url\\\":\\\"\\\"}\"},\"workspace\":1}',1,'0400$9vcTf1EXzQRtfa7VnD7gn0SLUDbt9pWC:595375f2fb9f014e091eb08fbc51ec88'),
(48,1792519997,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"},\"workspace\":1}',1,'0400$s2-x-bmgtvw_xvgVd69Zx-f9SmkEjAvz:df50bb24cbce671cf0d61f42fbbef601'),
(49,1792520063,1,'BE',1,0,3,'sys_file_reference','{\"pid\":4,\"tstamp\":1792520063,\"crdate\":1792520063,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":3,\"t3ver_wsid\":1,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"7\",\"title\":null,\"alternative\":null,\"uid_foreign\":5,\"tablenames\":\"tt_content\",\"fieldname\":\"assets\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":null,\"autoplay\":0,\"uid\":5,\"workspace\":1}',1,'0400$YH8IrqFglzTm75Z0oFs4ZYAlATvd6MMd:5f15a1453f67b933ed3314381f5d67e4'),
(50,1792520063,1,'BE',1,0,5,'tt_content','{\"pid\":4,\"tstamp\":1792520063,\"crdate\":1792520063,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"l18n_diffsource\":\"\",\"t3ver_oid\":5,\"t3ver_wsid\":1,\"t3ver_state\":0,\"t3ver_stage\":0,\"frame_class\":\"default\",\"colPos\":\"0\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"CType\":\"textmedia\",\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"Ogg\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\"ogging,\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\/p>\",\"image\":0,\"assets\":\"3\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"8\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"list_type\":\"\",\"media\":0,\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"uid\":7,\"workspace\":1}',1,'0400$YH8IrqFglzTm75Z0oFs4ZYAlATvd6MMd:ea41b626baac59a1fe0716bc344af5d9'),
(51,1792520063,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"header\":\"Ogg\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Ogg format\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"assets\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"workspace\":1}',1,'0400$WrFKUcoXb3ahudFr8El-DUY5ovo2R1N0:ea41b626baac59a1fe0716bc344af5d9'),
(52,1792520063,1,'BE',1,0,4,'sys_file_reference','{\"pid\":4,\"tstamp\":1792520063,\"crdate\":1792520063,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":1,\"l10n_parent\":\"3\",\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"assets\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"5\\\",\\\"uid_local\\\":\\\"7\\\"}\",\"t3ver_oid\":4,\"t3ver_wsid\":1,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"7\",\"title\":null,\"alternative\":null,\"uid_foreign\":6,\"tablenames\":\"tt_content\",\"fieldname\":\"assets\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":null,\"autoplay\":0,\"uid\":6,\"workspace\":1}',1,'0400$n9ZZ1anM2JM-33NfbruhJWdKmYELq8nx:768f9cd4e98812f969df7ebe17f11b50'),
(53,1792520063,1,'BE',1,0,6,'tt_content','{\"pid\":4,\"tstamp\":1792520063,\"crdate\":1792520063,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":1,\"l18n_parent\":\"5\",\"l10n_source\":5,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textmedia\\\",\\\"assets\\\":\\\"1\\\",\\\"bodytext\\\":\\\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\\\\\"ogging,\\\\\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Ogg\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"0\\\",\\\"imageorient\\\":\\\"8\\\",\\\"imagewidth\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"list_type\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"t3ver_oid\":6,\"t3ver_wsid\":1,\"t3ver_state\":0,\"t3ver_stage\":0,\"frame_class\":\"default\",\"colPos\":\"0\",\"table_caption\":null,\"tx_impexp_origuid\":0,\"CType\":\"textmedia\",\"categories\":\"0\",\"layout\":\"0\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"Ogg\",\"header_layout\":\"0\",\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Ogg ist ein digitales Multimedia-Containerformat, das f\\u00fcr ein effizientes Streaming sowie die Bearbeitung digitaler Multimedia-Inhalte konzipiert wurde. Es wird von der Xiph.Org Foundation gepflegt, ist frei und offen sowie frei von Softwarepatenten. Der Name leitet sich von \\u201eogging\\u201c ab \\u2013 einem Fachbegriff aus dem Computerspiel Netrek[4] \\u2013, was auf den hohen Rechenaufwand der fr\\u00fchen Versionen dieser Software anspielt.<\\/p>\",\"image\":0,\"assets\":\"4\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"8\",\"imageborder\":0,\"image_zoom\":0,\"imagecols\":\"2\",\"pages\":\"\",\"recursive\":\"0\",\"list_type\":\"\",\"media\":0,\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"uid\":8,\"workspace\":1}',1,'0400$n9ZZ1anM2JM-33NfbruhJWdKmYELq8nx:2097d84972a039cb6bfe093b17089287'),
(54,1792520063,2,'BE',1,0,3,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"workspace\":1}',1,'0400$WrFKUcoXb3ahudFr8El-DUY5ovo2R1N0:5f15a1453f67b933ed3314381f5d67e4'),
(55,1792520085,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Ogg\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textmedia\\\",\\\"assets\\\":\\\"1\\\",\\\"bodytext\\\":\\\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\\\\\"ogging,\\\\\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Ogg\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"0\\\",\\\"imageorient\\\":\\\"8\\\",\\\"imagewidth\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"list_type\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\"},\"newRecord\":{\"header\":\"Ogg Format\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textmedia\\\",\\\"assets\\\":\\\"1\\\",\\\"bodytext\\\":\\\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\\\\\"ogging,\\\\\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Ogg format\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"0\\\",\\\"imageorient\\\":\\\"8\\\",\\\"imagewidth\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"list_type\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\"},\"workspace\":1}',1,'0400$TSNzajCN-QDFQit1uxzVAMmIMSd35jHy:2097d84972a039cb6bfe093b17089287'),
(56,1792520318,7,'BE',1,NULL,6,'tt_content','{\"oldRecord\":{\"uid\":6,\"pid\":4,\"tstamp\":1792512763,\"crdate\":1792511506,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":1,\"l18n_parent\":5,\"l10n_source\":5,\"l10n_state\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textmedia\\\",\\\"assets\\\":\\\"1\\\",\\\"bodytext\\\":\\\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\\\\\"ogging,\\\\\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Ogg\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"0\\\",\\\"imageorient\\\":\\\"8\\\",\\\"imagewidth\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"list_type\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"frame_class\":\"default\",\"colPos\":0,\"table_caption\":null,\"tx_impexp_origuid\":0,\"CType\":\"textmedia\",\"categories\":0,\"layout\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"Ogg\",\"header_layout\":0,\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Ogg ist ein digitales Multimedia-Containerformat, das f\\u00fcr ein effizientes Streaming sowie die Bearbeitung digitaler Multimedia-Inhalte konzipiert wurde. Es wird von der Xiph.Org Foundation gepflegt, ist frei und offen sowie frei von Softwarepatenten. Der Name leitet sich von \\u201eogging\\u201c ab \\u2013 einem Fachbegriff aus dem Computerspiel Netrek[4] \\u2013, was auf den hohen Rechenaufwand der fr\\u00fchen Versionen dieser Software anspielt.<\\/p>\",\"image\":0,\"assets\":1,\"imagewidth\":0,\"imageheight\":0,\"imageorient\":8,\"imageborder\":0,\"image_zoom\":0,\"imagecols\":2,\"pages\":\"\",\"recursive\":0,\"list_type\":\"\",\"media\":0,\"records\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":\"0\",\"category_field\":\"\",\"bullets_type\":0,\"cols\":0,\"table_class\":\"\",\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":0},\"newRecord\":{\"tstamp\":1792520085,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"textmedia\\\",\\\"assets\\\":\\\"1\\\",\\\"bodytext\\\":\\\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\\\\\"ogging,\\\\\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\\\\\/p>\\\",\\\"bullets_type\\\":\\\"0\\\",\\\"categories\\\":\\\"0\\\",\\\"category_field\\\":\\\"\\\",\\\"colPos\\\":\\\"0\\\",\\\"cols\\\":\\\"0\\\",\\\"date\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"fe_group\\\":\\\"\\\",\\\"file_collections\\\":\\\"\\\",\\\"filelink_size\\\":\\\"0\\\",\\\"filelink_sorting\\\":\\\"\\\",\\\"filelink_sorting_direction\\\":\\\"\\\",\\\"frame_class\\\":\\\"default\\\",\\\"header\\\":\\\"Ogg format\\\",\\\"header_layout\\\":\\\"0\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"0\\\",\\\"image\\\":\\\"0\\\",\\\"image_zoom\\\":\\\"0\\\",\\\"imageborder\\\":\\\"0\\\",\\\"imagecols\\\":\\\"2\\\",\\\"imageheight\\\":\\\"0\\\",\\\"imageorient\\\":\\\"8\\\",\\\"imagewidth\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"linkToTop\\\":\\\"0\\\",\\\"list_type\\\":\\\"\\\",\\\"media\\\":\\\"0\\\",\\\"pages\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"records\\\":\\\"\\\",\\\"recursive\\\":\\\"0\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"1\\\",\\\"selected_categories\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"0\\\",\\\"subheader\\\":\\\"\\\",\\\"table_caption\\\":\\\"\\\",\\\"table_class\\\":\\\"\\\",\\\"table_delimiter\\\":\\\"124\\\",\\\"table_enclosure\\\":\\\"0\\\",\\\"table_header_position\\\":\\\"0\\\",\\\"table_tfoot\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"0\\\",\\\"uploads_description\\\":\\\"0\\\",\\\"uploads_type\\\":\\\"0\\\"}\",\"header\":\"Ogg Format\"},\"workspaceId\":1,\"comment\":\"\",\"recipients\":[]}',0,'0400$c0db6803ab1ec5f70c36e2a72187867b'),
(57,1792520318,7,'BE',1,NULL,5,'tt_content','{\"oldRecord\":{\"uid\":5,\"pid\":4,\"tstamp\":1792503239,\"crdate\":1792503239,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"frame_class\":\"default\",\"colPos\":0,\"table_caption\":null,\"tx_impexp_origuid\":0,\"CType\":\"textmedia\",\"categories\":0,\"layout\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"date\":0,\"header\":\"Ogg\",\"header_layout\":0,\"header_position\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\"ogging,\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\/p>\",\"image\":0,\"assets\":1,\"imagewidth\":0,\"imageheight\":0,\"imageorient\":8,\"imageborder\":0,\"image_zoom\":0,\"imagecols\":2,\"pages\":null,\"recursive\":0,\"list_type\":\"\",\"media\":0,\"records\":null,\"sectionIndex\":1,\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":null,\"category_field\":\"\",\"bullets_type\":0,\"cols\":0,\"table_class\":\"\",\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"uploads_description\":0,\"uploads_type\":0},\"newRecord\":{\"tstamp\":1792520063,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"assets\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\",\"header\":\"Ogg format\",\"selected_categories\":\"0\"},\"workspaceId\":1,\"comment\":\"\",\"recipients\":[]}',0,'0400$c7626fc9bcba6f70beb6ebc085a400db'),
(58,1792520318,7,'BE',1,NULL,4,'sys_file_reference','{\"oldRecord\":{\"uid\":4,\"pid\":4,\"tstamp\":1792520063,\"crdate\":1792511506,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":1,\"l10n_parent\":3,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"autoplay\\\":\\\"0\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"fieldname\\\":\\\"assets\\\",\\\"hidden\\\":\\\"0\\\",\\\"link\\\":\\\"\\\",\\\"sorting_foreign\\\":\\\"1\\\",\\\"tablenames\\\":\\\"tt_content\\\",\\\"title\\\":\\\"\\\",\\\"uid_foreign\\\":\\\"5\\\",\\\"uid_local\\\":\\\"7\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":7,\"title\":null,\"alternative\":null,\"uid_foreign\":6,\"tablenames\":\"tt_content\",\"fieldname\":\"assets\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":null,\"autoplay\":0},\"newRecord\":{\"tstamp\":1792520085},\"workspaceId\":1,\"comment\":\"\",\"recipients\":[]}',0,'0400$cea5fcd7b97871880cfe3717d6b52ef4'),
(59,1792520318,7,'BE',1,NULL,3,'sys_file_reference','{\"oldRecord\":{\"uid\":3,\"pid\":4,\"tstamp\":1792520063,\"crdate\":1792503239,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":7,\"title\":null,\"alternative\":null,\"uid_foreign\":5,\"tablenames\":\"tt_content\",\"fieldname\":\"assets\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":null,\"autoplay\":0},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"workspaceId\":1,\"comment\":\"\",\"recipients\":[]}',0,'0400$d2c609347a4764200256b39b9425159a'),
(60,1792520318,7,'BE',1,NULL,3,'pages','{\"oldRecord\":{\"uid\":3,\"pid\":2,\"tstamp\":1792516732,\"crdate\":1792500897,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":19,\"perms_everybody\":0,\"SYS_LASTCHANGED\":1792516732,\"shortcut\":0,\"content_from_pid\":0,\"mount_pid\":0,\"tx_impexp_origuid\":0,\"sitemap_priority\":\"0.5\",\"doktype\":1,\"title\":\"Ebene 2\",\"slug\":\"\\/meine-testseite\\/ebene-2\",\"TSconfig\":\"\",\"php_tree_stop\":0,\"categories\":0,\"layout\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"url\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":0,\"cache_tags\":\"\",\"no_search\":0,\"shortcut_mode\":0,\"keywords\":\"\",\"description\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"media\":0,\"is_siteroot\":0,\"mount_pid_ol\":0,\"module\":\"\",\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"twitter_card\":\"\"},\"newRecord\":{\"tstamp\":1792519997,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"workspaceId\":1,\"comment\":\"\",\"recipients\":[]}',0,'0400$fe15eeb7d49e64e2cea91ab53fcf0db1'),
(61,1792520318,7,'BE',1,NULL,6,'pages','{\"oldRecord\":{\"uid\":6,\"pid\":2,\"tstamp\":1792516782,\"crdate\":1792516782,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_parent\":3,\"l10n_source\":3,\"l10n_state\":\"{\\\"nav_hide\\\":\\\"parent\\\",\\\"url\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"l10n_diffsource\":\"{\\\"l10n_source\\\":\\\"0\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\",\\\"title\\\":\\\"Ebene 2\\\",\\\"url\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":19,\"perms_everybody\":0,\"SYS_LASTCHANGED\":0,\"shortcut\":0,\"content_from_pid\":0,\"mount_pid\":0,\"tx_impexp_origuid\":0,\"sitemap_priority\":\"0.5\",\"doktype\":1,\"title\":\"[Translate to German:] Ebene 2\",\"slug\":\"\\/meine-testseite\\/translate-to-german-ebene-2\",\"TSconfig\":null,\"php_tree_stop\":0,\"categories\":0,\"layout\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"url\":\"\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":0,\"cache_tags\":\"\",\"no_search\":0,\"shortcut_mode\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"media\":0,\"is_siteroot\":0,\"mount_pid_ol\":0,\"module\":\"\",\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"\"},\"newRecord\":{\"tstamp\":1792519994,\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"0\\\",\\\"content_from_pid\\\":\\\"0\\\",\\\"editlock\\\":\\\"0\\\",\\\"endtime\\\":\\\"0\\\",\\\"extendToSubpages\\\":\\\"0\\\",\\\"is_siteroot\\\":\\\"0\\\",\\\"l10n_source\\\":\\\"0\\\",\\\"l18n_cfg\\\":\\\"0\\\",\\\"lastUpdated\\\":\\\"0\\\",\\\"layout\\\":\\\"0\\\",\\\"media\\\":\\\"0\\\",\\\"module\\\":\\\"\\\",\\\"mount_pid\\\":\\\"0\\\",\\\"mount_pid_ol\\\":\\\"0\\\",\\\"nav_hide\\\":\\\"0\\\",\\\"newUntil\\\":\\\"0\\\",\\\"no_follow\\\":\\\"0\\\",\\\"no_index\\\":\\\"0\\\",\\\"no_search\\\":\\\"0\\\",\\\"og_image\\\":\\\"0\\\",\\\"php_tree_stop\\\":\\\"0\\\",\\\"shortcut\\\":\\\"0\\\",\\\"shortcut_mode\\\":\\\"0\\\",\\\"slug\\\":\\\"\\\\\\/meine-testseite\\\\\\/ebene-2\\\",\\\"starttime\\\":\\\"0\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"Ebene 2\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_image\\\":\\\"0\\\",\\\"url\\\":\\\"\\\"}\"},\"workspaceId\":1,\"comment\":\"\",\"recipients\":[]}',0,'0400$c75354c439a48dbde16b03ac553a080d'),
(62,1792592693,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$sOXcvE9eXJJELF0nmCRQ_Ri1NHcMEiGl:35af6288617af54964e77af08c30949a'),
(63,1792593230,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$IybU2S4aDOYT-eALHFZiyF6RROHpHhsq:35af6288617af54964e77af08c30949a'),
(64,1792593351,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$rCw5tsirXD1-Xwq4pQdHnqfNDTaTcFBu:35af6288617af54964e77af08c30949a'),
(65,1792601122,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$pAZb3oTfx22s8r4zxITcwhmyMBs_bLN9:f11830df10b4b0bca2db34810c2241b3'),
(66,1792601793,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__two_columns\"},\"newRecord\":{\"backend_layout\":\"-1\"}}',0,'0400$cXfKa5WOyY4f1Q_GZajEPrz_ZLYEXDVi:f11830df10b4b0bca2db34810c2241b3'),
(67,1792601798,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"-1\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\"}}',0,'0400$cn4QlOL6PKVDeMfWrlssT1q4_SBWywZz:f11830df10b4b0bca2db34810c2241b3'),
(68,1792602677,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__two_columns\"},\"newRecord\":{\"backend_layout\":\"-1\"}}',0,'0400$4ZEPeCvuoPKLhjb0dfqSAyiOjzPp_zfM:f11830df10b4b0bca2db34810c2241b3'),
(69,1792602681,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"-1\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\"}}',0,'0400$vGpt1VgLPxePEkpdolD0jxpkH2CEJbPB:f11830df10b4b0bca2db34810c2241b3'),
(70,1792602858,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__two_columns\"},\"newRecord\":{\"backend_layout\":\"-1\"}}',0,'0400$-nWBMCz0wKe9sHuJK_SQEQbh1TXvecc9:f11830df10b4b0bca2db34810c2241b3'),
(71,1792602867,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"-1\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\"}}',0,'0400$xe0MdnF2yN-41g6Kd8L0yEPp3fBwPUFC:f11830df10b4b0bca2db34810c2241b3'),
(72,1792603005,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__two_columns\"},\"newRecord\":{\"backend_layout\":\"-1\"}}',0,'0400$_ROlY4wAiAj7lIMXp_nTzlb9eytFZpKh:f11830df10b4b0bca2db34810c2241b3'),
(73,1792603009,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"-1\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\"}}',0,'0400$-MH3RopdR_-jPxCLiesBFX5GhiHzFxKG:f11830df10b4b0bca2db34810c2241b3'),
(74,1792603460,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__two_columns\"},\"newRecord\":{\"backend_layout\":\"-1\"}}',0,'0400$DOMio4bKIl-kx328e2fHXP0oeMKdvOMD:f11830df10b4b0bca2db34810c2241b3'),
(75,1792603465,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"-1\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\"}}',0,'0400$dF3bHvql9PjSEfRXvuDRizeHbqPJgG_W:f11830df10b4b0bca2db34810c2241b3'),
(76,1792603562,3,'BE',1,0,3,'tt_content','{\"oldData\":{\"pid\":2,\"tstamp\":1792416528,\"sorting\":768},\"newData\":{\"tstamp\":1792603562,\"sorting\":128,\"pid\":2}}',0,'0400$5QcrsHV1BgvTmOFXjP5zdz6xp10JW0z9:b92300cfb5d1d3645c9cb212a7f56c1f'),
(77,1792603562,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$mFnL_fQnsX4fuYR5L1aV9yi0FK62kroz:b92300cfb5d1d3645c9cb212a7f56c1f'),
(78,1792603606,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"imageorient\":18,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"imageorient\":\"8\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$bVpaMqKtm6Om6d4Y4FiRzv-h3xZXnwGY:b92300cfb5d1d3645c9cb212a7f56c1f'),
(79,1792603606,2,'BE',1,0,1,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$bVpaMqKtm6Om6d4Y4FiRzv-h3xZXnwGY:4cf496f597e7b095ce8b755e6cec3c0c'),
(80,1792603678,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__two_columns\"},\"newRecord\":{\"backend_layout\":\"-1\"}}',0,'0400$WX-KoEaA-O5CC4Cyqm11Ija4klaCQ7sU:f11830df10b4b0bca2db34810c2241b3'),
(81,1792603701,3,'BE',1,0,3,'tt_content','{\"oldData\":{\"pid\":2,\"tstamp\":1792603606,\"sorting\":128},\"newData\":{\"tstamp\":1792603701,\"sorting\":768,\"pid\":2}}',0,'0400$1njIx3Br3KVXPRRaBz2TVSwIcHFZI-lB:b92300cfb5d1d3645c9cb212a7f56c1f'),
(82,1792603701,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"colPos\":1,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"colPos\":\"0\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$B38jwGsxKUWjBgyuF5wz1JnoLMDVtmSs:b92300cfb5d1d3645c9cb212a7f56c1f'),
(83,1792603914,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"-1\"},\"newRecord\":{\"backend_layout\":\"pagets__two_columns\"}}',0,'0400$7AogFX0VoUinhfijmpe3lsbhYcvMvfyh:f11830df10b4b0bca2db34810c2241b3'),
(84,1792603954,3,'BE',1,0,2,'tt_content','{\"oldData\":{\"pid\":2,\"tstamp\":1792415738,\"sorting\":512},\"newData\":{\"tstamp\":1792603954,\"sorting\":128,\"pid\":2}}',0,'0400$z2zCc3GFugV0IYxtnqt37p2SSYgXn7S-:01dbc21fdb1263685b9147b3b1596ea8'),
(85,1792603954,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"colPos\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"colPos\":\"1\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$18q1WR-ZipKB4XdYaIO2jQ6X8BvbvGFJ:01dbc21fdb1263685b9147b3b1596ea8'),
(86,1792604326,3,'BE',1,0,3,'tt_content','{\"oldData\":{\"pid\":2,\"tstamp\":1792603701,\"sorting\":768},\"newData\":{\"tstamp\":1792604326,\"sorting\":192,\"pid\":2}}',0,'0400$eHNWGwZHyXUgBaGhl4ZTi90dMOkH-C-7:b92300cfb5d1d3645c9cb212a7f56c1f'),
(87,1792604326,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"colPos\":0},\"newRecord\":{\"colPos\":\"1\"}}',0,'0400$TCkEe6Z0EM3p2b30e1glaMy_6CVJlgn9:b92300cfb5d1d3645c9cb212a7f56c1f'),
(88,1792674815,1,'BE',1,0,7,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"8\",\"sys_language_uid\":0,\"crdate\":1792674815,\"t3ver_stage\":0,\"tstamp\":1792674815,\"uid\":7}',0,'0400$7oFxtC_5q5Pro_YHRL-0pcw4Gt2p5no0:117c97010b9af15cb554d115dba4e316'),
(89,1792675111,1,'BE',1,0,9,'tt_content','{\"CType\":\"mein_site_package_teaser_card\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":64,\"sys_language_uid\":0,\"header\":\"Leipzig\",\"bodytext\":\"<p>Leipzig[a] is the most populous city in the German state of Saxony. The city has a population of 633,592 residents as of 31 December 2025.[8] It is the eighth-largest city in Germany and is part of the Central German Metropolitan Region. Leipzig is located about 150 km (90 mi) southwest of Berlin, in the southernmost part of the North German Plain (the Leipzig Bay), at the confluence of the White Elster and its tributaries Plei\\u00dfe and Parthe.<\\/p>\",\"meinsitepackage_teasercard_link\":\"https:\\/\\/en.wikipedia.org\\/wiki\\/Leipzig\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792675111,\"t3ver_stage\":0,\"tstamp\":1792675111,\"uid\":9}',0,'0400$GbbJApX8cuB1HeVm_EG3S8sHFTdkHoXL:367f4f227870d8e2a11496a182574aa3'),
(90,1792675111,1,'BE',1,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"8\",\"sys_language_uid\":0,\"crdate\":1792675111,\"t3ver_stage\":0,\"tstamp\":1792675111,\"uid\":8}',0,'0400$GbbJApX8cuB1HeVm_EG3S8sHFTdkHoXL:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(91,1792675900,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Leipzig[a] is the most populous city in the German state of Saxony. The city has a population of 633,592 residents as of 31 December 2025.[8] It is the eighth-largest city in Germany and is part of the Central German Metropolitan Region. Leipzig is located about 150 km (90 mi) southwest of Berlin, in the southernmost part of the North German Plain (the Leipzig Bay), at the confluence of the White Elster and its tributaries Plei\\u00dfe and Parthe.<\\/p>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<p>Leipzig is the most populous city in the German state of Saxony. The city has a population of 633,592 residents as of 31 December 2025. It is the eighth-largest city in Germany and is part of the Central German Metropolitan Region. Leipzig is located about 150 km (90 mi) southwest of Berlin, in the southernmost part of the North German Plain (the Leipzig Bay), at the confluence of the White Elster and its tributaries Plei\\u00dfe and Parthe.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"meinsitepackage_teasercard_image\\\":\\\"\\\",\\\"meinsitepackage_teasercard_link\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$3sn4U8mFs-wVHowc9BcBGcn1-EIMaEw2:367f4f227870d8e2a11496a182574aa3'),
(92,1792675900,2,'BE',1,0,8,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$3sn4U8mFs-wVHowc9BcBGcn1-EIMaEw2:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(93,1792683074,1,'BE',1,0,9,'pages','{\"doktype\":\"254\",\"slug\":\"\\/meine-testseite\\/news-speicher\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News-Speicher\",\"sys_language_uid\":0,\"crdate\":1792683074,\"t3ver_stage\":0,\"tstamp\":1792683074,\"uid\":9}',0,'0400$mZRn5yBq6XliE8lwWwwnujbF3rPa9A0u:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(94,1792683233,2,'BE',1,0,9,'pages','{\"oldRecord\":{\"module\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"module\":\"news\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\"}}',0,'0400$d5COJeDzf8sUpOIMeYwOwh9a0Qk___6t:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(95,1792683919,1,'BE',1,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"braille-device-could-remove-barriers-to-science\",\"sitemap_priority\":\"0.5\",\"pid\":9,\"type\":\"0\",\"title\":\"Braille device could remove barriers to science\",\"teaser\":\"A blind university lecturer says a new braille device could help people with sight loss study and work in science, technology, engineering and maths (STEM).\\r\\n\\r\\nThe Canute Scientific has been created by Bristol Braille, a not-for-profit company that builds specialist technology with braille users.\",\"datetime\":1792683494,\"archive\":0,\"bodytext\":\"<p>A blind university lecturer says a new braille device could help people with sight loss study and work in science, technology, engineering and maths (STEM).<\\/p>\\r\\n<p>The Canute Scientific has been created by Bristol Braille, a not-for-profit company that builds specialist technology with braille users.<br \\/>Magentamobil S | 30 GB | Telekom | Top Handytarif | Inklusive 4 GB Roaming<br \\/>Magentamobil S | 30 GB | Telekom | Top Handytarif | Inklusive 4 GB Roaming<br \\/>Telekom \\u00b7 Sponsored<br \\/>call to action icon<\\/p>\\r\\n<p>Designed to display complex scientific and mathematical information in braille, it is hoped the device will help break down barriers for people pursuing STEM subjects and careers.<\\/p>\\r\\n<p>For Bath Spa University lecturer Hollie Baker, the technology could make a significant difference. \\\"It is essentially a computer, with a multi-line braille display integrated into it,\\\" she said.<\\/p>\\r\\n<p>The Canute Scientific looks similar to a computer keyboard, but contains rows of holes through which braille dots move up and down, allowing users to feel information displayed on screen.<\\/p>\\r\\n<p>\\\"The braille shows exactly the same thing as is on the visual screen. This means you can do things like edit text files \\u2013 or custom apps to view data,\\\" said Baker.<br \\/>Hollie is an associate lecturer in computer science and creative computing at Bath Spa University<br \\/>Hollie is an associate lecturer in computer science and creative computing at Bath Spa University \\u00a9 BBC<\\/p>\\r\\n<p>Across the UK, about two million people are living with sight loss, including around 340,000 people who are registered blind or partially sighted.<\\/p>\\r\\n<p>Around 20,000 people use braille.<\\/p>\\r\\n<p>Baker said accessing information while teaching had previously been difficult.<\\/p>\\r\\n<p>She had found it \\\"challenging\\\" to refer to her notes while delivering a lecture smoothly.<\\/p>\\r\\n<p>\\\"Without multi-line braille, I\'m relying on either a single line of braille which is like reading through a letterbox, or synthetic speech. And I find having speech babbling in my ear puts me off.\\\"<br \\/>Ed Rogers managing director at Bristol Braille says the machines are changing lives, for the better<br \\/>Ed Rogers managing director at Bristol Braille says the machines are changing lives, for the better \\u00a9 BBC<\\/p>\\r\\n<p>The idea for a system of using raised dots to represent letters and numbers, to be read using your fingers, was first invented by French teenager\\u2013 Louis Braille \\u2013 back in the 1820s.<\\/p>\\r\\n<p>Since then, it has transformed the lives of millions of people around the world, allowing them access to a world which was previously completely inaccessible.<br \\/>Deutsches Reich 1933 4Er-Block Mi-Nr 498 Chicagofahrt Postfr. Gepr.<br \\/>Deutsches Reich 1933 4Er-Block Mi-Nr 498 Chicagofahrt Postfr. Gepr.<br \\/>eBay DE \\u00b7 Sponsored<br \\/>call to action icon<\\/p>\\r\\n<p>Bristol Braille is the not-for-profit company behind the invention of the Canute Scientific.<\\/p>\\r\\n<p>The company was founded and managed by Ed Rogers who says these machines are changing lives, for the better.<\\/p>\\r\\n<p>\\\"Braille is traditionally embossed into paper,\\\" he said.<\\/p>\\r\\n<p>\\\"It\'s a series of dots making up a single character. Those constitute anything in text, numbers, music scores but there is an issue when it comes to getting that digitised.<\\/p>\\r\\n<p>\\\"The Canute Scientific has a braille display on the front.<\\/p>\\r\\n<p>\\\"There are slots through which the dots come, representing the braille characters and that is representing data in the same way that a visual monitor is.\\\"<br \\/>Hollie\'s class at Bath Spa University listen to herdelivering a computing lecture<br \\/>Hollie\'s class at Bath Spa University listen to herdelivering a computing lecture \\u00a9 BBC<\\/p>\\r\\n<p>Chris Turner has been working at Bristol Braille for about a year.<\\/p>\\r\\n<p>He describes himself as blind and says the machines they\'re making here are transforming lives.<\\/p>\\r\\n<p>\\\"The machines are built here so if a customer wants to speak to someone who\'s built the machine, they can.<\\/p>\\r\\n<p>\\\"If there\'s an issue we\'re all here and we can work on it.\\\"<\\/p>\\r\\n\\r\\n\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1792683919,\"t3ver_stage\":0,\"tstamp\":1792683919,\"uid\":1}',0,'0400$oxjUPM3dJBcmP9OcpHdM1U0kDOvqZ64L:fccd16ea3664ec003726b2a72ea38f4b'),
(96,1792684047,1,'BE',1,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"primate-thought-lost-turns-up-in-indonesia\",\"sitemap_priority\":\"0.5\",\"pid\":9,\"type\":\"0\",\"title\":\"Primate thought lost  turns up in Indonesia\",\"teaser\":\"A big-eyed, venomous primate that had not been documented in scientific literature since the 1930s has been hiding in plain sight on the Indonesian island of Bangka, turning up in backyards, along roadsides and on power lines and prompting local residents who find them to call the Alobi Wildlife Rescue Center for help.\",\"datetime\":1792683938,\"archive\":0,\"bodytext\":\"<p>A big-eyed, venomous primate that had not been documented in scientific literature since the 1930s has been hiding in plain sight on the Indonesian island of Bangka, turning up in backyards, along roadsides and on power lines and prompting local residents who find them to call the Alobi Wildlife Rescue Center for help.<\\/p>\\r\\n<p>A new study published in the scientific journal Spixiana confirms that the Bangka slow loris, one of Re:wild\'s most wanted lost primates, still survives across much of the island. The evidence comes from more than 90 Bangka slow lorises that Alobi rescued between 2015 and 2025.<\\/p>\\r\\n<p>The Alobi center co-authored the published study with the Haus des Meeres Aqua Terra Zoo in Vienna and the Taman Safari Prigen Conservation Breeding Ark. The study\'s publication coincides with the celebration of Lost Species Month in October.<\\/p>\\r\\n<p>The Bangka slow loris is classified as critically endangered (possibly extinct) by the IUCN Red List of Threatened Species. Although scientists had not documented the species in nearly a century, it was never lost to the people of Bangka. For more than a decade, Alobi has been rescuing slow lorises reported by residents and local authorities across the island, caring for the animals and returning those that recover to protected forest. Until now, those encounters had not made their way into the scientific literature.<\\/p>\\r\\n<p>The study began with a conversation in Java. While visiting the Taman Safari Prigen Conservation Breeding Ark, study co-author Timon Glaw of the Haus des Meeres Aqua Terra Zoo learned from conservationist Jochen Menner that the Bangka slow loris was listed as critically endangered (possibly extinct) by the IUCN Red List and was among Re:wild\'s most wanted lost primates. Menner connected him with Alobi, where he learned that the rescue center had something the scientific record did not: documented encounters with the species.<\\/p>\\r\\n<p>That discovery brought Alobi, Haus des Meeres Aqua Terra Zoo and the Taman Safari Prigen Conservation Breeding Ark together to analyze the records and publish the new study.<\\/p>\\r\\n<p>\\\"We are glad to contribute to the scientific record to show that the Bangka slow loris is not lost, but the species is still very close to extinction,\\\" said Langka Sani, director of the Alobi Wildlife Rescue Center. \\\"Its natural habitat on Bangka Island has shrunk significantly because of illegal tin mining and massive land clearing for oil palm plantations. We ask people around the world to support us in saving the Bangka slow loris while we still can.\\\"<\\/p>\\r\\n<p>According to the study, Alobi rescued Bangka slow lorises in all four regencies of Bangka Island and in the city of Pangkal Pinang, which suggests the species may still live across much of the island. Of the more than 90 slow lorises Alobi rescued, 86 recovered and were released at seven sites on Bangka. Alobi\'s team chose the release sites carefully, focusing on the island\'s larger forest fragments that can still provide good habitat and have some level of legal or practical protection.<\\/p>\\r\\n<p>\\\"Bringing the Bangka slow loris back onto the scientific radar is only the first step,\\\" Glaw said. \\\"We now know the species has survived in several parts of Bangka, and we urgently need a long-term conservation strategy built on population surveys, genetic studies and, above all, protection of its remaining habitat. The next challenge is to make sure it does not actually become extinct.\\\"<\\/p>\\r\\n<p>Discover the latest in science, tech, and space with over 100,000 subscribers who rely on Phys.org for daily insights. Sign up for our free newsletter and get updates on breakthroughs, innovations, and research that matter\\u2014daily or weekly.<\\/p>\\r\\n<p>Bangka Island is home to more than 1 million people. According to the study, human settlements, roads and power lines are significant threats to the species. Slow lorises are also a target for the pet trade across their range in Asia.<\\/p>\\r\\n<p>The study\'s authors recommend a conservation program on Bangka that protects suitable habitat and continues monitored releases following IUCN Species Survival Commission guidelines. They also propose a conservation breeding program that could help conservationists learn more about the species\' biology and behavior. Next steps include population surveys, genetic studies and tracking how released slow lorises fare once they are back in the forest.<\\/p>\\r\\n<p>\\\"The team at Alobi has spent more than a decade quietly rescuing, healing and releasing these animals, and their careful records are what have finally brought this primate back into scientific view,\\\" said Benji Barca, Re:wild\'s exploration program manager.<br \\/>\\\"It is another reminder that conservation depends on the knowledge of local communities, Indigenous peoples and others who know these species and landscapes intimately. A species can disappear from the scientific record without disappearing from the lives of the people who share its home.\\\"<\\/p>\\r\\n<p>Slow lorises are among the world\'s most unusual primates. They are the only primates known to be venomous: They lick a gland on the inside of their upper arm and mix its secretion with saliva, producing a bite that can be painful and cause swelling.<\\/p>\\r\\n<p>Slow lorises have huge, round eyes for seeing in the dark, a comb of specialized lower teeth for grooming, and they move slowly, silently and deliberately through the trees so they blend in at night. The Bangka slow loris, a small, reddish-backed loris with a pale facial mask, was first scientifically described in 1906 but was only recognized as its own species in 2013.<\\/p>\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1792684047,\"t3ver_stage\":0,\"tstamp\":1792684047,\"uid\":2}',0,'0400$pY9J5n5YMPrJXYyEybIQJdjN4Dx7bZ0X:640f28e5c1a5ec2efb19c26699b464a5'),
(97,1792684128,1,'BE',1,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"perot-museum-announces-expansion\",\"sitemap_priority\":\"0.5\",\"pid\":9,\"type\":\"0\",\"title\":\"Perot Museum announces expansion\",\"teaser\":\"The Perot Museum of Nature and Science in Dallas has announced plans to expand. Leaders are expected to unveil the design on Tuesday, which will nearly double the campus\'s size with new experiences for visitors.\",\"datetime\":1792684058,\"archive\":0,\"bodytext\":\"<p>The Perot Museum of Nature and Science in Dallas has announced plans to expand. Leaders are expected to unveil the design on Tuesday, which will nearly double the campus\'s size with new experiences for visitors.<\\/p>\\r\\n<p>Officials told CBS News Texas that the project\'s groundbreaking is expected to begin in early 2027, with completion in late 2028.<br \\/>Dieser neue Essens-Trend erreicht jetzt auch Gotha<br \\/>Dieser neue Essens-Trend erreicht jetzt auch Gotha<br \\/>Vital &amp; aktiv im Alltag \\u00b7 Sponsored<br \\/>call to action icon<\\/p>\\r\\n<p>The museum will expand by at least four acres, doubling exhibit space with 60,000 sq. ft. of outdoor science experiences. The new area will feature hands-on attractions, including a mist maze, geysers, a lightning and thunder pavilion, a giant water vortex and a fire tornado, officials said.<\\/p>\\r\\n<p>The project will also add new green space, upgraded amenities, and improved access for school groups.<\\/p>\\r\\n<p>So far, officials said the museum has reached $135 million of its $185 million fundraising campaign. Once finished, the expansion is expected to attract an additional 400,000 visitors each year.&nbsp;<\\/p>\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1792684128,\"t3ver_stage\":0,\"tstamp\":1792684128,\"uid\":3}',0,'0400$Fe5EszoVJpnvKWgNthC1baf52M3oUlf9:1152fda277b2623b0152b5765fcb6b28'),
(98,1792684527,1,'BE',1,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/news-detail\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News Detail\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"sitemap_changefreq\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"0\",\"no_search\":\"0\",\"php_tree_stop\":\"0\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"0\",\"nav_hide\":\"1\",\"extendToSubpages\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"sys_language_uid\":0,\"crdate\":1792684527,\"t3ver_stage\":0,\"tstamp\":1792684527,\"uid\":10}',0,'0400$wTEoNoZgR_FYl6Wqx2XDow0Qt_AckjIs:e904af5a60392ab3165f5849f5877e45'),
(99,1792684545,2,'BE',1,0,10,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$GmlCYVDExpd3l4VL6iu_qNFK-a6HtsF4:e904af5a60392ab3165f5849f5877e45'),
(100,1792684590,3,'BE',1,0,10,'pages','{\"oldData\":{\"pid\":1,\"tstamp\":1792684545,\"sorting\":128},\"newData\":{\"tstamp\":1792684590,\"sorting\":64,\"pid\":2}}',0,'0400$rHvzVhOfPDUNiD0Lta5OB-muHtVDPd4X:e904af5a60392ab3165f5849f5877e45'),
(101,1792684615,3,'BE',1,0,10,'pages','{\"oldData\":{\"pid\":2,\"tstamp\":1792684590,\"sorting\":64},\"newData\":{\"tstamp\":1792684615,\"sorting\":128,\"pid\":1}}',0,'0400$ortLHS7iBthc3rcJZsjRxsmBG8EBpWzy:e904af5a60392ab3165f5849f5877e45'),
(102,1792685015,2,'BE',1,0,10,'pages','{\"oldRecord\":{\"nav_hide\":1,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"0\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$jvk_FWwmag0lIGqV-5dB2lSjZmegvd4W:e904af5a60392ab3165f5849f5877e45'),
(103,1792685038,2,'BE',1,0,10,'pages','{\"oldRecord\":{\"nav_hide\":0},\"newRecord\":{\"nav_hide\":\"1\"}}',0,'0400$Uy1Ui3KuxXkPQ1DgbTagIhJprSeBLHkg:e904af5a60392ab3165f5849f5877e45'),
(104,1792686009,1,'BE',1,0,10,'tt_content','{\"CType\":\"news_pi1\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"News\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">9<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1792686009,\"t3ver_stage\":0,\"tstamp\":1792686009,\"uid\":10}',0,'0400$RjYdYb2JGMZsOdIuuv7RGR-YxOrzXUnP:7ea9bfd0f5c1068d25caf6ccac9d6265');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1792413044,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1792414464,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"1\"}',0,0,'',0,'','info',NULL,NULL),
(3,1792414468,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(4,1792415046,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(5,1792415058,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"4\"}',1,0,'',0,'','info',NULL,NULL),
(6,1792415543,1,1,1,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(7,1792415556,1,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"6\"}',2,0,'',0,'','info',NULL,NULL),
(8,1792415738,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(9,1792416263,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"images\",\"destination\":\"\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(10,1792416442,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"leipzig.jpg\",\"destination\":\"\\/images\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(11,1792416528,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(12,1792416528,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(13,1792416528,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(14,1792418282,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(15,1792497492,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(16,1792500897,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(17,1792500909,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"11\"}',2,0,'',0,'','info',NULL,NULL),
(18,1792500939,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(19,1792500945,1,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"history\":\"13\"}',3,0,'',0,'','info',NULL,NULL),
(20,1792501671,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(21,1792501842,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"15\"}',3,0,'',0,'','info',NULL,NULL),
(22,1792501864,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"16\"}',3,0,'',0,'','info',NULL,NULL),
(23,1792501893,1,1,0,'',0,1,'No file was uploaded',2,'file',0,'172.18.0.5','',-1,0,'',0,'','info',NULL,NULL),
(24,1792501901,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"sanda.jpeg\",\"destination\":\"\\/images\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(25,1792501918,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"17\"}',3,0,'',0,'','info',NULL,NULL),
(26,1792501918,1,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(27,1792501918,1,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"19\"}',3,0,'',0,'','info',NULL,NULL),
(28,1792502965,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"audio\",\"destination\":\"\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(29,1792502979,1,1,0,'',0,1,'Uploading file \"{identifier}\" to \"{destination}\" failed',2,'file',0,'172.18.0.5','{\"identifier\":\"example.ogg\",\"destination\":\"\\/audio\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(30,1792503192,1,1,0,'',0,1,'No file was uploaded',2,'file',0,'172.18.0.5','',-1,0,'',0,'','info',NULL,NULL),
(31,1792503201,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"example.ogg\",\"destination\":\"\\/audio\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(32,1792503239,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(33,1792503239,1,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(34,1792503239,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(35,1792510643,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(36,1792511183,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(37,1792511401,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"23\"}',3,0,'',0,'','info',NULL,NULL),
(38,1792511438,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"24\"}',3,0,'',0,'','info',NULL,NULL),
(39,1792511442,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(40,1792511506,1,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(41,1792511506,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(42,1792511506,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(43,1792511516,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"27\"}',3,0,'',0,'','info',NULL,NULL),
(44,1792511702,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"28\"}',4,0,'',0,'','info',NULL,NULL),
(45,1792511711,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(46,1792511781,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(47,1792511816,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"29\"}',4,0,'',0,'','info',NULL,NULL),
(48,1792511829,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(49,1792512763,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"30\"}',4,0,'',0,'','info',NULL,NULL),
(50,1792515127,1,1,1,'be_groups',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"be_groups\",\"uid\":1,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(51,1792515636,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"32\"}',2,0,'',0,'','info',NULL,NULL),
(52,1792515636,1,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"history\":\"33\"}',3,0,'',0,'','info',NULL,NULL),
(53,1792515636,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"34\"}',3,0,'',0,'','info',NULL,NULL),
(54,1792515895,1,1,2,'be_users',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"be_users\",\"uid\":2,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(55,1792516028,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,0,'',0,'','info',NULL,NULL),
(56,1792516064,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.5','[\"Willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(57,1792516093,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.5','[\"Willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(58,1792516110,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.5','[\"willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(59,1792516185,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(60,1792516289,1,2,2,'be_users',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"be_users\",\"uid\":2,\"history\":\"36\"}',0,0,'',0,'','info',NULL,NULL),
(61,1792516299,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,0,'',0,'','info',NULL,NULL),
(62,1792516317,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.5','[\"willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(63,1792516334,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(64,1792516365,1,2,2,'be_users',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"be_users\",\"uid\":2,\"history\":\"37\"}',0,0,'',0,'','info',NULL,NULL),
(65,1792516423,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,0,'',0,'','info',NULL,NULL),
(66,1792516437,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(67,1792516726,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"38\"}',2,0,'',0,'','info',NULL,NULL),
(68,1792516732,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"39\"}',2,0,'',0,'','info',NULL,NULL),
(69,1792516782,2,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(70,1792516861,2,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"willi\"]',-1,0,'',0,'','info',NULL,NULL),
(71,1792516865,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(72,1792517281,1,2,1,'be_groups',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"be_groups\",\"uid\":1,\"history\":\"41\"}',0,0,'',0,'','info',NULL,NULL),
(73,1792517393,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,0,'',0,'','info',NULL,NULL),
(74,1792517397,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(75,1792517882,2,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"willi\"]',-1,0,'',0,'','info',NULL,NULL),
(76,1792517885,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(77,1792518004,1,2,1,'be_groups',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"be_groups\",\"uid\":1,\"history\":\"42\"}',0,0,'',0,'','info',NULL,NULL),
(78,1792518008,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,0,'',0,'','info',NULL,NULL),
(79,1792518011,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(80,1792518032,2,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"willi\"]',-1,0,'',0,'','info',NULL,NULL),
(81,1792518043,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"willi\"]',-1,-99,'',0,'','info',NULL,NULL),
(82,1792518543,2,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"willi\"]',-1,0,'',0,'','info',NULL,NULL),
(83,1792518547,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(84,1792519102,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,0,'',0,'','info',NULL,NULL),
(85,1792519105,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(86,1792519812,1,1,1,'sys_workspace',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_workspace\",\"uid\":1,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(87,1792519859,1,0,0,'',0,0,'User changed workspace to \"{workspace}\"',4,'default',0,'172.18.0.5','{\"workspace\":1}',-1,1,'',0,'','info',NULL,NULL),
(88,1792519994,1,1,7,'pages',0,0,'New version created \"{table}:{uid}\". UID of new version is \"{offlineUid}\"',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":7,\"offlineUid\":7}',7,1,'',0,'','info',NULL,NULL),
(89,1792519994,1,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":7,\"history\":\"45\"}',2,1,'',0,'','info',NULL,NULL),
(90,1792519994,1,1,8,'pages',0,0,'New version created \"{table}:{uid}\". UID of new version is \"{offlineUid}\"',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"offlineUid\":8}',8,1,'',0,'','info',NULL,NULL),
(91,1792519994,1,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"history\":\"47\"}',2,1,'',0,'','info',NULL,NULL),
(92,1792519997,1,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":7,\"history\":\"48\"}',2,1,'',0,'','info',NULL,NULL),
(93,1792520015,1,0,0,'',0,0,'User changed workspace to \"{workspace}\"',4,'default',0,'172.18.0.5','{\"workspace\":0}',-1,0,'',0,'','info',NULL,NULL),
(94,1792520027,1,0,0,'',0,0,'User changed workspace to \"{workspace}\"',4,'default',0,'172.18.0.5','{\"workspace\":1}',-1,1,'',0,'','info',NULL,NULL),
(95,1792520063,1,1,5,'sys_file_reference',0,0,'New version created \"{table}:{uid}\". UID of new version is \"{offlineUid}\"',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":5,\"offlineUid\":5}',4,1,'',0,'','info',NULL,NULL),
(96,1792520063,1,1,7,'tt_content',0,0,'New version created \"{table}:{uid}\". UID of new version is \"{offlineUid}\"',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"offlineUid\":7}',4,1,'',0,'','info',NULL,NULL),
(97,1792520063,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":0}',4,1,'',0,'','info',NULL,NULL),
(98,1792520063,1,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"51\"}',4,1,'',0,'','info',NULL,NULL),
(99,1792520063,1,1,6,'sys_file_reference',0,0,'New version created \"{table}:{uid}\". UID of new version is \"{offlineUid}\"',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":6,\"offlineUid\":6}',4,1,'',0,'','info',NULL,NULL),
(100,1792520063,1,1,8,'tt_content',0,0,'New version created \"{table}:{uid}\". UID of new version is \"{offlineUid}\"',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"offlineUid\":8}',4,1,'',0,'','info',NULL,NULL),
(101,1792520063,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":0}',4,1,'',0,'','info',NULL,NULL),
(102,1792520063,1,2,5,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":5,\"history\":\"54\"}',4,1,'',0,'','info',NULL,NULL),
(103,1792520085,1,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"55\"}',4,1,'',0,'','info',NULL,NULL),
(104,1792520318,1,8,6,'tt_content',0,0,'Record \"{table}\" uid {liveId}=>{versionId} was published.',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"versionId\":8,\"liveId\":6}',4,1,'',0,'','info',NULL,NULL),
(105,1792520318,1,3,8,'tt_content',0,0,'Record {table}:{uid} was deleted unrecoverable from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"pid\":4}',4,1,'',0,'','info',NULL,NULL),
(106,1792520318,1,8,5,'tt_content',0,0,'Record \"{table}\" uid {liveId}=>{versionId} was published.',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"versionId\":7,\"liveId\":5}',4,1,'',0,'','info',NULL,NULL),
(107,1792520318,1,3,7,'tt_content',0,0,'Record {table}:{uid} was deleted unrecoverable from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":4}',4,1,'',0,'','info',NULL,NULL),
(108,1792520318,1,8,4,'sys_file_reference',0,0,'Record \"{table}\" uid {liveId}=>{versionId} was published.',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"versionId\":6,\"liveId\":4}',4,1,'',0,'','info',NULL,NULL),
(109,1792520318,1,3,6,'sys_file_reference',0,0,'Record {table}:{uid} was deleted unrecoverable from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":4}',4,1,'',0,'','info',NULL,NULL),
(110,1792520318,1,8,3,'sys_file_reference',0,0,'Record \"{table}\" uid {liveId}=>{versionId} was published.',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"versionId\":5,\"liveId\":3}',4,1,'',0,'','info',NULL,NULL),
(111,1792520318,1,3,5,'sys_file_reference',0,0,'Record {table}:{uid} was deleted unrecoverable from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":4}',4,1,'',0,'','info',NULL,NULL),
(112,1792520318,1,8,3,'pages',0,0,'Record \"{table}\" uid {liveId}=>{versionId} was published.',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"versionId\":7,\"liveId\":3}',2,1,'',0,'','info',NULL,NULL),
(113,1792520318,1,8,6,'pages',0,0,'Record \"{table}\" uid {liveId}=>{versionId} was published.',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"versionId\":8,\"liveId\":6}',2,1,'',0,'','info',NULL,NULL),
(114,1792520318,1,7,6,'tt_content',0,0,'Notification email for stage change was sent to \"{recipients}\"',1,'content',0,'172.18.0.5','{\"recipients\":\"\"}',4,1,'',0,'','info',NULL,NULL),
(115,1792520318,1,7,5,'tt_content',0,0,'Notification email for stage change was sent to \"{recipients}\"',1,'content',0,'172.18.0.5','{\"recipients\":\"\"}',4,1,'',0,'','info',NULL,NULL),
(116,1792520318,1,7,4,'sys_file_reference',0,0,'Notification email for stage change was sent to \"{recipients}\"',1,'content',0,'172.18.0.5','{\"recipients\":\"\"}',4,1,'',0,'','info',NULL,NULL),
(117,1792520318,1,7,3,'sys_file_reference',0,0,'Notification email for stage change was sent to \"{recipients}\"',1,'content',0,'172.18.0.5','{\"recipients\":\"\"}',4,1,'',0,'','info',NULL,NULL),
(118,1792520318,1,7,3,'pages',0,0,'Notification email for stage change was sent to \"{recipients}\"',1,'content',0,'172.18.0.5','{\"recipients\":\"\"}',2,1,'',0,'','info',NULL,NULL),
(119,1792520318,1,7,6,'pages',0,0,'Notification email for stage change was sent to \"{recipients}\"',1,'content',0,'172.18.0.5','{\"recipients\":\"\"}',2,1,'',0,'','info',NULL,NULL),
(120,1792520354,1,0,0,'',0,0,'User changed workspace to \"{workspace}\"',4,'default',0,'172.18.0.5','{\"workspace\":0}',-1,0,'',0,'','info',NULL,NULL),
(121,1792520984,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(122,1792521142,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(123,1792583144,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(124,1792588590,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(125,1792588594,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(126,1792589183,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(127,1792589203,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(128,1792589205,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(129,1792591353,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(130,1792591355,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(131,1792592693,1,2,1,'sys_template',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_template\",\"uid\":1,\"history\":\"62\"}',1,0,'',0,'','info',NULL,NULL),
(132,1792592714,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(133,1792592717,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(134,1792593182,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(135,1792593185,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(136,1792593189,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":2}',-1,0,'',0,'','info',NULL,NULL),
(137,1792593192,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(138,1792593194,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(139,1792593230,1,2,1,'sys_template',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_template\",\"uid\":1,\"history\":\"63\"}',1,0,'',0,'','info',NULL,NULL),
(140,1792593237,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(141,1792593239,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(142,1792593324,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(143,1792593326,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(144,1792593351,1,2,1,'sys_template',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_template\",\"uid\":1,\"history\":\"64\"}',1,0,'',0,'','info',NULL,NULL),
(145,1792594283,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(146,1792594285,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(147,1792595290,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(148,1792595950,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(149,1792595952,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(150,1792597206,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(151,1792597218,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(152,1792597220,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(153,1792598978,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(154,1792599134,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1225709595: The Fluid template files \"/var/www/html/vendor/guillermo/mein-site-package/Resources/Private/PageView/Partials/MainNavigation.html\", \"/var/www/html/vendor/guillermo/mein-site-package/Resources/Private/PageView/Partials/MainNavigation\" could not be loaded. | TYPO3Fluid\\Fluid\\View\\Exception\\InvalidTemplateResourceException thrown in file /var/www/html/vendor/typo3fluid/fluid/src/View/TemplatePaths.php in line 711. Requested URL: https://typo3-projekt.ddev.site/meine-testseite',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(155,1792599364,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(156,1792599366,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(157,1792601112,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(158,1792601122,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"65\"}',1,0,'',0,'','info',NULL,NULL),
(159,1792601135,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(160,1792601303,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(161,1792601543,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(162,1792601783,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(163,1792601793,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"66\"}',1,0,'',0,'','info',NULL,NULL),
(164,1792601798,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"67\"}',1,0,'',0,'','info',NULL,NULL),
(165,1792602651,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(166,1792602677,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"68\"}',1,0,'',0,'','info',NULL,NULL),
(167,1792602681,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"69\"}',1,0,'',0,'','info',NULL,NULL),
(168,1792602849,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(169,1792602858,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"70\"}',1,0,'',0,'','info',NULL,NULL),
(170,1792602867,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"71\"}',1,0,'',0,'','info',NULL,NULL),
(171,1792602877,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(172,1792602994,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(173,1792603005,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"72\"}',1,0,'',0,'','info',NULL,NULL),
(174,1792603009,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"73\"}',1,0,'',0,'','info',NULL,NULL),
(175,1792603023,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(176,1792603190,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(177,1792603452,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(178,1792603454,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(179,1792603460,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"74\"}',1,0,'',0,'','info',NULL,NULL),
(180,1792603465,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"75\"}',1,0,'',0,'','info',NULL,NULL),
(181,1792603562,1,4,3,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(182,1792603562,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"77\"}',2,0,'',0,'','info',NULL,NULL),
(183,1792603606,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"78\"}',2,0,'',0,'','info',NULL,NULL),
(184,1792603606,1,2,1,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"history\":\"79\"}',2,0,'',0,'','info',NULL,NULL),
(185,1792603678,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"80\"}',1,0,'',0,'','info',NULL,NULL),
(186,1792603701,1,4,3,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(187,1792603701,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"82\"}',2,0,'',0,'','info',NULL,NULL),
(188,1792603706,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1742058289: PAGEVIEW TypoScript object: Failed to resolve the expected template file \"Pages/None.html\" for layout \"none\". See also: https://docs.typo3.org/permalink/t3tsref:cobj-pageview@13.4. The following paths were checked: EXT:mein_site_package/Resources/Private/PageView/Pages/None.html | TYPO3Fluid\\Fluid\\View\\Exception\\InvalidTemplateResourceException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/PageViewContentObject.php in line 120. Requested URL: https://typo3-projekt.ddev.site/meine-testseite',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(189,1792603722,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(190,1792603723,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(191,1792603726,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1742058289: PAGEVIEW TypoScript object: Failed to resolve the expected template file \"Pages/None.html\" for layout \"none\". See also: https://docs.typo3.org/permalink/t3tsref:cobj-pageview@13.4. The following paths were checked: EXT:mein_site_package/Resources/Private/PageView/Pages/None.html | TYPO3Fluid\\Fluid\\View\\Exception\\InvalidTemplateResourceException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/PageViewContentObject.php in line 120. Requested URL: https://typo3-projekt.ddev.site/meine-testseite',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(192,1792603782,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(193,1792603788,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1742058289: PAGEVIEW TypoScript object: Failed to resolve the expected template file \"Pages/None.html\" for layout \"none\". See also: https://docs.typo3.org/permalink/t3tsref:cobj-pageview@13.4. The following paths were checked: EXT:mein_site_package/Resources/Private/PageView/Pages/None.html | TYPO3Fluid\\Fluid\\View\\Exception\\InvalidTemplateResourceException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/PageViewContentObject.php in line 120. Requested URL: https://typo3-projekt.ddev.site/meine-testseite',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(194,1792603914,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"83\"}',1,0,'',0,'','info',NULL,NULL),
(195,1792603954,1,4,2,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(196,1792603954,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"85\"}',2,0,'',0,'','info',NULL,NULL),
(197,1792604077,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(198,1792604079,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(199,1792604293,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(200,1792604326,1,4,3,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(201,1792604326,1,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"87\"}',2,0,'',0,'','info',NULL,NULL),
(202,1792604959,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(203,1792671681,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"t3admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(204,1792674221,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(205,1792674803,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"leipzig2.jpeg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(206,1792674815,1,1,0,'tt_content',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',0,'172.18.0.5','{\"reason\":\"An exception occurred while executing a query: Unknown column \'meinsitepackage_teasercard_link\' in \'INSERT INTO\'\",\"table\":\"tt_content\",\"uid\":\"NEW6ada0a7a4189f852441490\"}',-1,0,'',0,'','info',NULL,NULL),
(207,1792674815,1,1,7,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(208,1792675111,1,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(209,1792675111,1,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(210,1792675111,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(211,1792675659,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639672666: ViewHelper f:uri.resource needs an Extbase Request object to resolve extension name for given path \"Css/teaser-card.css\". If not in Extbase context, either set argument \"extensionName\", or (better) use the standard EXT: syntax for path attribute like \'path=\"EXT:indexed_search/Resources/Public/Icons/Extension.svg\"\'. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Uri/ResourceViewHelper.php in line 122. Requested URL: https://typo3-projekt.ddev.site/meine-testseite',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(212,1792675900,1,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"91\"}',2,0,'',0,'','info',NULL,NULL),
(213,1792675900,1,2,8,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":8,\"history\":\"92\"}',2,0,'',0,'','info',NULL,NULL),
(214,1792677406,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(215,1792683074,1,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(216,1792683233,1,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"94\"}',2,0,'',0,'','info',NULL,NULL),
(217,1792683919,1,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(218,1792684047,1,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(219,1792684128,1,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(220,1792684527,1,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(221,1792684545,1,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"99\"}',1,0,'',0,'','info',NULL,NULL),
(222,1792684551,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(223,1792684590,1,4,10,'pages',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":2}',1,0,'',0,'','info',NULL,NULL),
(224,1792684590,1,4,10,'pages',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":1}',2,0,'',0,'','info',NULL,NULL),
(225,1792684615,1,4,10,'pages',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":1}',2,0,'',0,'','info',NULL,NULL),
(226,1792684615,1,4,10,'pages',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":2}',1,0,'',0,'','info',NULL,NULL),
(227,1792685015,1,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"102\"}',1,0,'',0,'','info',NULL,NULL),
(228,1792685038,1,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"103\"}',1,0,'',0,'','info',NULL,NULL),
(229,1792685118,1,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(230,1792686009,1,1,10,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":10,\"pid\":10}',10,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_preview`
--

DROP TABLE IF EXISTS `sys_preview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_preview` (
  `keyword` varchar(32) NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `config` text DEFAULT NULL,
  PRIMARY KEY (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_preview`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_preview` WRITE;
/*!40000 ALTER TABLE `sys_preview` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_preview` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('10e3072c43dbb0977f016edd7f5c7e43','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('2a7a9e73c8d264db97bd8067af2bd65b','tt_content',5,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('332fcb0c39970ea0ddfcfd07558e2dff','be_users',2,'usergroup',0,0,2147483647,0,'','','',0,0,'be_groups',1,'',0,0,2147483647,0,0,''),
('3406d35585a11180f6ab6dd020a81121','tt_content',9,'meinsitepackage_teasercard_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('520f16ee913f05b4b8b8b0dd08a22050','tt_content',3,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('522e8d6cab27b43b6493fac5cd39a3ca','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('5315735fbbfd9b36ca4556716d400e4a','tt_content',6,'assets',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('5465c3d099f29563fdc762905d7614d8','tt_content',4,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('59991f241a1c82d24e9c3c1750002574','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('5d4be8e84ad89a00a38c5d627034aca2','sys_file_reference',4,'l10n_parent',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('680846d4e505ed308689ed3e32833b52','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('869a233ffd3b184868e581878ebe1089','tt_content',6,'l18n_parent',0,0,2147483647,0,'','','',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('9812ff5d3bb810ffb0c013ea997f5e77','tt_content',10,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',10,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b3f5a2b852966b20f3aa40ff8e5d1bb8','pages',6,'l10n_parent',1,0,2147483647,0,'','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('b5570bea58f3fbda33a09f2978f91c49','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('be946337d03fa309d745053940798df4','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('d6623a6573d0c83277ea4e2aec2f2460','be_groups',1,'db_mountpoints',0,0,2147483647,0,'','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('e05c770922b4ad576dd84aaf0893bd91','tt_content',10,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',9,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('fd177625b48cd479237fb91c847a450d','pages',5,'l10n_parent',0,0,2147483647,0,'','','',0,0,'pages',4,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\IndexedSearchCTypeMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Extensionmanager\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(12,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(23,'extensionDataImport','typo3/cms-core/ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','typo3/cms-extbase/ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','typo3/cms-fluid/ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','typo3/cms-install/ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','typo3/cms-backend/ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','typo3/cms-frontend/ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','typo3/cms-dashboard/ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','typo3/cms-fluid-styled-content/ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','typo3/cms-filelist/ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','typo3/cms-impexp/ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','typo3/cms-form/ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','typo3/cms-seo/ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','typo3/cms-setup/ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','typo3/cms-rte-ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','typo3/cms-sys-note/ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','typo3/cms-belog/ext_tables_static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','typo3/cms-beuser/ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','typo3/cms-extensionmanager/ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','typo3/cms-felogin/ext_tables_static+adt.sql','s:0:\"\";'),
(42,'extensionDataImport','typo3/cms-info/ext_tables_static+adt.sql','s:0:\"\";'),
(43,'extensionDataImport','typo3/cms-reactions/ext_tables_static+adt.sql','s:0:\"\";'),
(44,'extensionDataImport','typo3/cms-recycler/ext_tables_static+adt.sql','s:0:\"\";'),
(45,'extensionDataImport','typo3/cms-tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),
(46,'extensionDataImport','typo3/cms-viewpage/ext_tables_static+adt.sql','s:0:\"\";'),
(47,'extensionDataImport','typo3/cms-webhooks/ext_tables_static+adt.sql','s:0:\"\";'),
(48,'extensionDataImport','typo3/cms-workspaces/ext_tables_static+adt.sql','s:0:\"\";'),
(49,'core','formProtectionSessionToken:1','s:64:\"4d4f25798788d3d462e78b25a88250947658f0c5c7150da1130cc784c96b04ac\";'),
(50,'extensionDataImport','guillermo/mein-site-package/ext_tables_static+adt.sql','s:0:\"\";'),
(51,'extensionDataImport','friendsoftypo3/content-blocks/ext_tables_static+adt.sql','s:0:\"\";'),
(52,'extensionDataImport','georgringer/news/ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1792593351,1792413041,0,1,0,0,0,'This is an Empty Site Package TypoScript record.\n\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject/Configuration/TypoScript/setup.typoscript\'',0,'Main TypoScript Rendering',1,3,'','EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/',NULL,0,'page = PAGE\npage.10 = TEXT\npage.10.value (\n   <div style=\"width: 800px; margin: 15% auto;\">\n      <div style=\"width: 300px;\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 150 42\"><path d=\"M60.2 14.4v27h-3.8v-27h-6.7v-3.3h17.1v3.3h-6.6zm20.2 12.9v14h-3.9v-14l-7.7-16.2h4.1l5.7 12.2 5.7-12.2h3.9l-7.8 16.2zm19.5 2.6h-3.6v11.4h-3.8V11.1s3.7-.3 7.3-.3c6.6 0 8.5 4.1 8.5 9.4 0 6.5-2.3 9.7-8.4 9.7m.4-16c-2.4 0-4.1.3-4.1.3v12.6h4.1c2.4 0 4.1-1.6 4.1-6.3 0-4.4-1-6.6-4.1-6.6m21.5 27.7c-7.1 0-9-5.2-9-15.8 0-10.2 1.9-15.1 9-15.1s9 4.9 9 15.1c.1 10.6-1.8 15.8-9 15.8m0-27.7c-3.9 0-5.2 2.6-5.2 12.1 0 9.3 1.3 12.4 5.2 12.4 3.9 0 5.2-3.1 5.2-12.4 0-9.4-1.3-12.1-5.2-12.1m19.9 27.7c-2.1 0-5.3-.6-5.7-.7v-3.1c1 .2 3.7.7 5.6.7 2.2 0 3.6-1.9 3.6-5.2 0-3.9-.6-6-3.7-6H138V24h3.1c3.5 0 3.7-3.6 3.7-5.3 0-3.4-1.1-4.8-3.2-4.8-1.9 0-4.1.5-5.3.7v-3.2c.5-.1 3-.7 5.2-.7 4.4 0 7 1.9 7 8.3 0 2.9-1 5.5-3.3 6.3 2.6.2 3.8 3.1 3.8 7.3 0 6.6-2.5 9-7.3 9\"/><path fill=\"#FF8700\" d=\"M31.7 28.8c-.6.2-1.1.2-1.7.2-5.2 0-12.9-18.2-12.9-24.3 0-2.2.5-3 1.3-3.6C12 1.9 4.3 4.2 1.9 7.2 1.3 8 1 9.1 1 10.6c0 9.5 10.1 31 17.3 31 3.3 0 8.8-5.4 13.4-12.8M28.4.5c6.6 0 13.2 1.1 13.2 4.8 0 7.6-4.8 16.7-7.2 16.7-4.4 0-9.9-12.1-9.9-18.2C24.5 1 25.6.5 28.4.5\"/></svg>\n      </div>\n      <h4 style=\"font-family: sans-serif;\">Welcome to a default website made with <a href=\"https://typo3.org\">TYPO3</a></h4>\n   </div>\n)\npage.100 = CONTENT\npage.100 {\n    table = tt_content\n    select {\n        orderBy = sorting\n        where = {#colPos}=0\n    }\n}\n',0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_workspace`
--

DROP TABLE IF EXISTS `sys_workspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_workspace` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(30) NOT NULL DEFAULT '',
  `adminusers` longtext DEFAULT NULL,
  `members` longtext DEFAULT NULL,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `publish_time` bigint(20) NOT NULL DEFAULT 0,
  `freeze` smallint(5) unsigned NOT NULL DEFAULT 0,
  `live_edit` smallint(5) unsigned NOT NULL DEFAULT 0,
  `publish_access` smallint(5) unsigned NOT NULL DEFAULT 0,
  `previewlink_lifetime` int(11) NOT NULL DEFAULT 0,
  `stagechg_notification` smallint(5) unsigned NOT NULL DEFAULT 1,
  `custom_stages` int(10) unsigned NOT NULL DEFAULT 0,
  `edit_notification_defaults` longtext DEFAULT NULL,
  `edit_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `edit_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 2,
  `publish_notification_defaults` longtext DEFAULT NULL,
  `publish_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `publish_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 1,
  `execute_notification_defaults` longtext DEFAULT NULL,
  `execute_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `execute_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 3,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_workspace` WRITE;
/*!40000 ALTER TABLE `sys_workspace` DISABLE KEYS */;
INSERT INTO `sys_workspace` VALUES
(1,0,1792519812,0,'','MeinSpace','','','','',0,0,0,0,48,1,0,'',3,2,'',3,1,'',3,3);
/*!40000 ALTER TABLE `sys_workspace` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_workspace_stage`
--

DROP TABLE IF EXISTS `sys_workspace_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_workspace_stage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `parentid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(30) NOT NULL DEFAULT '',
  `responsible_persons` longtext DEFAULT NULL,
  `default_mailcomment` longtext DEFAULT NULL,
  `notification_defaults` longtext DEFAULT NULL,
  `allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 8,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace_stage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_workspace_stage` WRITE;
/*!40000 ALTER TABLE `sys_workspace_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace_stage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `meinsitepackage_teasercard_image` int(10) unsigned NOT NULL DEFAULT 0,
  `meinsitepackage_teasercard_link` text NOT NULL DEFAULT '',
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`,`l18n_parent`,`sys_language_uid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,2,1792415556,1792415543,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Erstes Element',0,'','','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'',0),
(2,2,1792603954,1792415738,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'header',0,0,'','',0,'Zweites Element',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'',0),
(3,2,1792604326,1792416528,0,0,0,0,'',192,'',0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',1,NULL,0,'textpic',0,0,'','',0,'Drittes Element ist ein Bild mit Text',0,'','','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',1,0,0,0,8,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'',0),
(4,3,1792501918,1792501671,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Sanda Island Lighthouse',0,'','','','<p><i>From Wikipedia, the free encyclopedia</i></p>\r\n<p>The Sanda Island Lighthouse is a lighthouse on Sanda Island, Argyll and Bute, United Kingdom.</p>\r\n<p>One of the thirteen major lighthouses designed and built by Alan Stevenson, the lighthouse was established in 1850, after a series of shipwrecks in the area. The three \"steps\" of the lighthouse were due to the cliff on which it was built, and remains a unique design in Scotland.</p>\r\n<p>Automated in 1991, the lighthouse is operated by the Northern Lighthouse Board, and designated a Category A listed building.</p>',1,0,0,0,17,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'',0),
(5,4,1792520063,1792503239,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"assets\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'textmedia',0,0,'','',0,'Ogg format',0,'','','','<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \"ogging,\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.</p>',0,1,0,0,8,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'',0),
(6,4,1792520085,1792511506,0,0,0,0,'',512,'',0,1,5,5,NULL,'{\"CType\":\"textmedia\",\"assets\":\"1\",\"bodytext\":\"<p>Ogg is a digital multimedia container file format designed to provide for efficient streaming and manipulation of digital multimedia. It is maintained by the Xiph.Org Foundation and is free and open, unrestricted by software patents. Its name is derived from \\\"ogging,\\\" jargon from the computer game Netrek,[4] alluding to the high processing cost of early versions of the software.<\\/p>\",\"bullets_type\":\"0\",\"categories\":\"0\",\"category_field\":\"\",\"colPos\":\"0\",\"cols\":\"0\",\"date\":\"0\",\"editlock\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"file_collections\":\"\",\"filelink_size\":\"0\",\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"frame_class\":\"default\",\"header\":\"Ogg format\",\"header_layout\":\"0\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"0\",\"image\":\"0\",\"image_zoom\":\"0\",\"imageborder\":\"0\",\"imagecols\":\"2\",\"imageheight\":\"0\",\"imageorient\":\"8\",\"imagewidth\":\"0\",\"l10n_source\":\"0\",\"layout\":\"0\",\"linkToTop\":\"0\",\"list_type\":\"\",\"media\":\"0\",\"pages\":\"\",\"pi_flexform\":\"\",\"records\":\"\",\"recursive\":\"0\",\"rowDescription\":\"\",\"sectionIndex\":\"1\",\"selected_categories\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"0\",\"subheader\":\"\",\"table_caption\":\"\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":\"0\",\"target\":\"\",\"tx_impexp_origuid\":\"0\",\"uploads_description\":\"0\",\"uploads_type\":\"0\"}',0,0,0,0,'default',0,NULL,0,'textmedia',0,0,'','',0,'Ogg Format',0,'','','','<p>Ogg ist ein digitales Multimedia-Containerformat, das für ein effizientes Streaming sowie die Bearbeitung digitaler Multimedia-Inhalte konzipiert wurde. Es wird von der Xiph.Org Foundation gepflegt, ist frei und offen sowie frei von Softwarepatenten. Der Name leitet sich von „ogging“ ab – einem Fachbegriff aus dem Computerspiel Netrek[4] –, was auf den hohen Rechenaufwand der frühen Versionen dieser Software anspielt.</p>',0,1,0,0,8,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,0,'',0),
(9,2,1792675900,1792675111,0,0,0,0,'',64,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"hidden\":\"\",\"meinsitepackage_teasercard_image\":\"\",\"meinsitepackage_teasercard_link\":\"\",\"rowDescription\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'mein_site_package_teaser_card',0,0,'','',0,'Leipzig',0,'','','','<p>Leipzig is the most populous city in the German state of Saxony. The city has a population of 633,592 residents as of 31 December 2025. It is the eighth-largest city in Germany and is part of the Central German Metropolitan Region. Leipzig is located about 150 km (90 mi) southwest of Berlin, in the southernmost part of the North German Plain (the Leipzig Bay), at the confluence of the White Elster and its tributaries Pleiße and Parthe.</p>',0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,1,'https://en.wikipedia.org/wiki/Leipzig',0),
(10,10,1792686009,1792686009,0,0,0,0,'',256,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'news_pi1',0,0,'','',0,'News',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">9</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'',0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
('',1,9,1792683919,1792683919,0,0,0,0,'',0,0,0,0,NULL,0,'',0,0,0,0,0,'Braille device could remove barriers to science','A blind university lecturer says a new braille device could help people with sight loss study and work in science, technology, engineering and maths (STEM).\r\n\r\nThe Canute Scientific has been created by Bristol Braille, a not-for-profit company that builds specialist technology with braille users.','<p>A blind university lecturer says a new braille device could help people with sight loss study and work in science, technology, engineering and maths (STEM).</p>\r\n<p>The Canute Scientific has been created by Bristol Braille, a not-for-profit company that builds specialist technology with braille users.<br />Magentamobil S | 30 GB | Telekom | Top Handytarif | Inklusive 4 GB Roaming<br />Magentamobil S | 30 GB | Telekom | Top Handytarif | Inklusive 4 GB Roaming<br />Telekom · Sponsored<br />call to action icon</p>\r\n<p>Designed to display complex scientific and mathematical information in braille, it is hoped the device will help break down barriers for people pursuing STEM subjects and careers.</p>\r\n<p>For Bath Spa University lecturer Hollie Baker, the technology could make a significant difference. \"It is essentially a computer, with a multi-line braille display integrated into it,\" she said.</p>\r\n<p>The Canute Scientific looks similar to a computer keyboard, but contains rows of holes through which braille dots move up and down, allowing users to feel information displayed on screen.</p>\r\n<p>\"The braille shows exactly the same thing as is on the visual screen. This means you can do things like edit text files – or custom apps to view data,\" said Baker.<br />Hollie is an associate lecturer in computer science and creative computing at Bath Spa University<br />Hollie is an associate lecturer in computer science and creative computing at Bath Spa University © BBC</p>\r\n<p>Across the UK, about two million people are living with sight loss, including around 340,000 people who are registered blind or partially sighted.</p>\r\n<p>Around 20,000 people use braille.</p>\r\n<p>Baker said accessing information while teaching had previously been difficult.</p>\r\n<p>She had found it \"challenging\" to refer to her notes while delivering a lecture smoothly.</p>\r\n<p>\"Without multi-line braille, I\'m relying on either a single line of braille which is like reading through a letterbox, or synthetic speech. And I find having speech babbling in my ear puts me off.\"<br />Ed Rogers managing director at Bristol Braille says the machines are changing lives, for the better<br />Ed Rogers managing director at Bristol Braille says the machines are changing lives, for the better © BBC</p>\r\n<p>The idea for a system of using raised dots to represent letters and numbers, to be read using your fingers, was first invented by French teenager– Louis Braille – back in the 1820s.</p>\r\n<p>Since then, it has transformed the lives of millions of people around the world, allowing them access to a world which was previously completely inaccessible.<br />Deutsches Reich 1933 4Er-Block Mi-Nr 498 Chicagofahrt Postfr. Gepr.<br />Deutsches Reich 1933 4Er-Block Mi-Nr 498 Chicagofahrt Postfr. Gepr.<br />eBay DE · Sponsored<br />call to action icon</p>\r\n<p>Bristol Braille is the not-for-profit company behind the invention of the Canute Scientific.</p>\r\n<p>The company was founded and managed by Ed Rogers who says these machines are changing lives, for the better.</p>\r\n<p>\"Braille is traditionally embossed into paper,\" he said.</p>\r\n<p>\"It\'s a series of dots making up a single character. Those constitute anything in text, numbers, music scores but there is an issue when it comes to getting that digitised.</p>\r\n<p>\"The Canute Scientific has a braille display on the front.</p>\r\n<p>\"There are slots through which the dots come, representing the braille characters and that is representing data in the same way that a visual monitor is.\"<br />Hollie\'s class at Bath Spa University listen to herdelivering a computing lecture<br />Hollie\'s class at Bath Spa University listen to herdelivering a computing lecture © BBC</p>\r\n<p>Chris Turner has been working at Bristol Braille for about a year.</p>\r\n<p>He describes himself as blind and says the machines they\'re making here are transforming lives.</p>\r\n<p>\"The machines are built here so if a customer wants to speak to someone who\'s built the machine, they can.</p>\r\n<p>\"If there\'s an issue we\'re all here and we can work on it.\"</p>\r\n\r\n',1792683494,0,'','',0,0,0,0,0,'0','','',0,0,NULL,NULL,0,0,'braille-device-could-remove-barriers-to-science','','',0.5,'',''),
('',2,9,1792684047,1792684047,0,0,0,0,'',0,0,0,0,NULL,0,'',0,0,0,0,0,'Primate thought lost  turns up in Indonesia','A big-eyed, venomous primate that had not been documented in scientific literature since the 1930s has been hiding in plain sight on the Indonesian island of Bangka, turning up in backyards, along roadsides and on power lines and prompting local residents who find them to call the Alobi Wildlife Rescue Center for help.','<p>A big-eyed, venomous primate that had not been documented in scientific literature since the 1930s has been hiding in plain sight on the Indonesian island of Bangka, turning up in backyards, along roadsides and on power lines and prompting local residents who find them to call the Alobi Wildlife Rescue Center for help.</p>\r\n<p>A new study published in the scientific journal Spixiana confirms that the Bangka slow loris, one of Re:wild\'s most wanted lost primates, still survives across much of the island. The evidence comes from more than 90 Bangka slow lorises that Alobi rescued between 2015 and 2025.</p>\r\n<p>The Alobi center co-authored the published study with the Haus des Meeres Aqua Terra Zoo in Vienna and the Taman Safari Prigen Conservation Breeding Ark. The study\'s publication coincides with the celebration of Lost Species Month in October.</p>\r\n<p>The Bangka slow loris is classified as critically endangered (possibly extinct) by the IUCN Red List of Threatened Species. Although scientists had not documented the species in nearly a century, it was never lost to the people of Bangka. For more than a decade, Alobi has been rescuing slow lorises reported by residents and local authorities across the island, caring for the animals and returning those that recover to protected forest. Until now, those encounters had not made their way into the scientific literature.</p>\r\n<p>The study began with a conversation in Java. While visiting the Taman Safari Prigen Conservation Breeding Ark, study co-author Timon Glaw of the Haus des Meeres Aqua Terra Zoo learned from conservationist Jochen Menner that the Bangka slow loris was listed as critically endangered (possibly extinct) by the IUCN Red List and was among Re:wild\'s most wanted lost primates. Menner connected him with Alobi, where he learned that the rescue center had something the scientific record did not: documented encounters with the species.</p>\r\n<p>That discovery brought Alobi, Haus des Meeres Aqua Terra Zoo and the Taman Safari Prigen Conservation Breeding Ark together to analyze the records and publish the new study.</p>\r\n<p>\"We are glad to contribute to the scientific record to show that the Bangka slow loris is not lost, but the species is still very close to extinction,\" said Langka Sani, director of the Alobi Wildlife Rescue Center. \"Its natural habitat on Bangka Island has shrunk significantly because of illegal tin mining and massive land clearing for oil palm plantations. We ask people around the world to support us in saving the Bangka slow loris while we still can.\"</p>\r\n<p>According to the study, Alobi rescued Bangka slow lorises in all four regencies of Bangka Island and in the city of Pangkal Pinang, which suggests the species may still live across much of the island. Of the more than 90 slow lorises Alobi rescued, 86 recovered and were released at seven sites on Bangka. Alobi\'s team chose the release sites carefully, focusing on the island\'s larger forest fragments that can still provide good habitat and have some level of legal or practical protection.</p>\r\n<p>\"Bringing the Bangka slow loris back onto the scientific radar is only the first step,\" Glaw said. \"We now know the species has survived in several parts of Bangka, and we urgently need a long-term conservation strategy built on population surveys, genetic studies and, above all, protection of its remaining habitat. The next challenge is to make sure it does not actually become extinct.\"</p>\r\n<p>Discover the latest in science, tech, and space with over 100,000 subscribers who rely on Phys.org for daily insights. Sign up for our free newsletter and get updates on breakthroughs, innovations, and research that matter—daily or weekly.</p>\r\n<p>Bangka Island is home to more than 1 million people. According to the study, human settlements, roads and power lines are significant threats to the species. Slow lorises are also a target for the pet trade across their range in Asia.</p>\r\n<p>The study\'s authors recommend a conservation program on Bangka that protects suitable habitat and continues monitored releases following IUCN Species Survival Commission guidelines. They also propose a conservation breeding program that could help conservationists learn more about the species\' biology and behavior. Next steps include population surveys, genetic studies and tracking how released slow lorises fare once they are back in the forest.</p>\r\n<p>\"The team at Alobi has spent more than a decade quietly rescuing, healing and releasing these animals, and their careful records are what have finally brought this primate back into scientific view,\" said Benji Barca, Re:wild\'s exploration program manager.<br />\"It is another reminder that conservation depends on the knowledge of local communities, Indigenous peoples and others who know these species and landscapes intimately. A species can disappear from the scientific record without disappearing from the lives of the people who share its home.\"</p>\r\n<p>Slow lorises are among the world\'s most unusual primates. They are the only primates known to be venomous: They lick a gland on the inside of their upper arm and mix its secretion with saliva, producing a bite that can be painful and cause swelling.</p>\r\n<p>Slow lorises have huge, round eyes for seeing in the dark, a comb of specialized lower teeth for grooming, and they move slowly, silently and deliberately through the trees so they blend in at night. The Bangka slow loris, a small, reddish-backed loris with a pale facial mask, was first scientifically described in 1906 but was only recognized as its own species in 2013.</p>',1792683938,0,'','',0,0,0,0,0,'0','','',0,0,NULL,NULL,0,0,'primate-thought-lost-turns-up-in-indonesia','','',0.5,'',''),
('',3,9,1792684128,1792684128,0,0,0,0,'',0,0,0,0,NULL,0,'',0,0,0,0,0,'Perot Museum announces expansion','The Perot Museum of Nature and Science in Dallas has announced plans to expand. Leaders are expected to unveil the design on Tuesday, which will nearly double the campus\'s size with new experiences for visitors.','<p>The Perot Museum of Nature and Science in Dallas has announced plans to expand. Leaders are expected to unveil the design on Tuesday, which will nearly double the campus\'s size with new experiences for visitors.</p>\r\n<p>Officials told CBS News Texas that the project\'s groundbreaking is expected to begin in early 2027, with completion in late 2028.<br />Dieser neue Essens-Trend erreicht jetzt auch Gotha<br />Dieser neue Essens-Trend erreicht jetzt auch Gotha<br />Vital &amp; aktiv im Alltag · Sponsored<br />call to action icon</p>\r\n<p>The museum will expand by at least four acres, doubling exhibit space with 60,000 sq. ft. of outdoor science experiences. The new area will feature hands-on attractions, including a mist maze, geysers, a lightning and thunder pavilion, a giant water vortex and a fire tornado, officials said.</p>\r\n<p>The project will also add new green space, upgraded amenities, and improved access for school groups.</p>\r\n<p>So far, officials said the museum has reached $135 million of its $185 million fundraising campaign. Once finished, the expansion is expected to attract an additional 400,000 visitors each year.&nbsp;</p>',1792684058,0,'','',0,0,0,0,0,'0','','',0,0,NULL,NULL,0,0,'perot-museum-announces-expansion','','',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`,`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-23 13:38:39
